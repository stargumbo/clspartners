<?php return array (
  'manifest-version' => '1.1',
  'manifest-attributes' => 
  array (
  ),
  'manifest-vehicles' => 
  array (
    0 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modNamespace',
      'guid' => 'b7d2c8388c3553c49177e52639458f63',
      'native_key' => 'core',
      'filename' => 'modNamespace/8abdfdff9ff11746b24ffbfc5ee89f08.vehicle',
    ),
    1 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modWorkspace',
      'guid' => 'a5b3ab6bc81bf724cd42074f7ce81f42',
      'native_key' => 1,
      'filename' => 'modWorkspace/3d59b0839461f6dc27afef49dadc8150.vehicle',
    ),
    2 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modTransportProvider',
      'guid' => '95305a18ebfa292cda4be0178e6877ab',
      'native_key' => 1,
      'filename' => 'modTransportProvider/b3dec73ee8bdcde771e94d2ba59f2f17.vehicle',
    ),
    3 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAction',
      'guid' => 'e96cd6a0d8cb1e70da6a34fb7c54a7f0',
      'native_key' => 1,
      'filename' => 'modAction/cc5e895eac84b4431a33352f426fea0f.vehicle',
    ),
    4 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAction',
      'guid' => '1ece2c686fda56a9f0746a92fd94fb3c',
      'native_key' => 3,
      'filename' => 'modAction/36897a2f9469f2d0be8cbdb901399eed.vehicle',
    ),
    5 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAction',
      'guid' => 'a37d2126d3bcc505116dbbfb7cfe0d0f',
      'native_key' => 5,
      'filename' => 'modAction/004e2683c0cbd041d2005f289418abd1.vehicle',
    ),
    6 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAction',
      'guid' => '50de4b9ab86c2eee36ada5cc791742a7',
      'native_key' => 7,
      'filename' => 'modAction/f3b34bc733f27b3291dcab8402c863a4.vehicle',
    ),
    7 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAction',
      'guid' => '72000539f02d3f580cc4966440496050',
      'native_key' => 8,
      'filename' => 'modAction/8991257bc9c811766de65f3094de8815.vehicle',
    ),
    8 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAction',
      'guid' => '9f63ee06d1a4421fe524c260c7b2973d',
      'native_key' => 9,
      'filename' => 'modAction/3d69b38eeb02baf07538dde95823953b.vehicle',
    ),
    9 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAction',
      'guid' => '94f53ee1fb4e8cd479e4a79e06ffdc28',
      'native_key' => 10,
      'filename' => 'modAction/bc36c6c141ba957b9446bc30b2cbe13d.vehicle',
    ),
    10 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAction',
      'guid' => '4130e605e7d001f68532ea442ebd8b5d',
      'native_key' => 11,
      'filename' => 'modAction/30c73bd7f3fe18c7cef036ebaae0e85f.vehicle',
    ),
    11 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAction',
      'guid' => '1a60c5086aaf6823e6ead1023ca6d1ff',
      'native_key' => 12,
      'filename' => 'modAction/9b962d8275863fe1fdd1017e1da9d592.vehicle',
    ),
    12 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAction',
      'guid' => '1d093c1e5ad26cb21446ec294b5285bf',
      'native_key' => 13,
      'filename' => 'modAction/3e384e283b70ef7bbdacbafdb187df99.vehicle',
    ),
    13 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAction',
      'guid' => '8945bafd54bc966eb417cc573281d68d',
      'native_key' => 20,
      'filename' => 'modAction/7b88a6c4f674de23b6786ea2238acef6.vehicle',
    ),
    14 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAction',
      'guid' => '4c6b74143fe3b4eba8b1989d2b0ca8f6',
      'native_key' => 21,
      'filename' => 'modAction/210cf19e2d8883c786c0157fe7bbbff3.vehicle',
    ),
    15 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAction',
      'guid' => '5500faac0a2d53c3df79e390f9f723db',
      'native_key' => 22,
      'filename' => 'modAction/cbcb31511b0aeeea5076b0966f3e6446.vehicle',
    ),
    16 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAction',
      'guid' => '6bb01649e19cef118bfe92b64fb562fb',
      'native_key' => 25,
      'filename' => 'modAction/7e255976702d85b29999e3309ed1642e.vehicle',
    ),
    17 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAction',
      'guid' => '1e3153b451ba33939885cb509222648e',
      'native_key' => 26,
      'filename' => 'modAction/0d98a3c952d90b50d9bbb5cc5de08c90.vehicle',
    ),
    18 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAction',
      'guid' => '48a7fd07aa58192dceafd4bfba9bb3a2',
      'native_key' => 27,
      'filename' => 'modAction/8361d05dc4c7332ddf9d71f4179e40b1.vehicle',
    ),
    19 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAction',
      'guid' => '2b41ad5ac492df865f859cd3e0c578bb',
      'native_key' => 28,
      'filename' => 'modAction/12fb60eb2b0351489a5467be06afaeca.vehicle',
    ),
    20 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAction',
      'guid' => '72bb29a7c0aee366f1e45da67c563f3f',
      'native_key' => 29,
      'filename' => 'modAction/481d327f50bb7f6229e85851439e9bbf.vehicle',
    ),
    21 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAction',
      'guid' => '92855b73ec4abaea456acfe2ecc5de6a',
      'native_key' => 30,
      'filename' => 'modAction/30909987a480e789d0b0fe1ee2cefc92.vehicle',
    ),
    22 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAction',
      'guid' => '063889aed39b0b05a6ac8f1b8f7ca17c',
      'native_key' => 31,
      'filename' => 'modAction/589d0203857217a91166cbb6d4654e5e.vehicle',
    ),
    23 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAction',
      'guid' => 'd7b34c8d7c1f42dbeda21daaa6b6a78e',
      'native_key' => 32,
      'filename' => 'modAction/d57b8ef24270aa3b852b83cf49d30612.vehicle',
    ),
    24 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAction',
      'guid' => '0bb42f1b2a2fd757961c0dc5033c5ff9',
      'native_key' => 33,
      'filename' => 'modAction/7541c43268ba31083fbe0aed42f3c4d2.vehicle',
    ),
    25 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAction',
      'guid' => 'e960dedfb12c12da01f3c625de209274',
      'native_key' => 34,
      'filename' => 'modAction/3cf44f24a344b168e0662d978f239125.vehicle',
    ),
    26 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAction',
      'guid' => 'dc45e48f0a08331fbcaac8b86c984c68',
      'native_key' => 35,
      'filename' => 'modAction/fb8c49d5aa741ff390c3995a4a2d2a03.vehicle',
    ),
    27 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAction',
      'guid' => 'b6fbedffc8399f4668f3f9397633bfa5',
      'native_key' => 36,
      'filename' => 'modAction/7c6f03d79a33c7e91882144b7b8f25e7.vehicle',
    ),
    28 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAction',
      'guid' => '321e467097b7f3ce14c72c7bfd98c2b8',
      'native_key' => 38,
      'filename' => 'modAction/5796c7d9e51cc070f8abd3d5fbc29f18.vehicle',
    ),
    29 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAction',
      'guid' => 'c8de53189d2ddb5b1ad8c9946f55dd95',
      'native_key' => 39,
      'filename' => 'modAction/9f0a02ee6449a6cbeef82edf0e7bbb1d.vehicle',
    ),
    30 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAction',
      'guid' => '7d26a4d641878f1acfc3833e772f8274',
      'native_key' => 40,
      'filename' => 'modAction/e7d5759d94287ef33e467410d3c40e12.vehicle',
    ),
    31 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAction',
      'guid' => 'dd48ab7b5dd7eec967b6df5ce1a5389c',
      'native_key' => 41,
      'filename' => 'modAction/6241255fcd6a6c1ec25bff7d0691bdc7.vehicle',
    ),
    32 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAction',
      'guid' => '43cdb004e6ce10084cf1cf49efa2d19a',
      'native_key' => 43,
      'filename' => 'modAction/da2398a8456ed5517604062aa059a087.vehicle',
    ),
    33 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAction',
      'guid' => '88398dc1d3ed1662b4f6e065a7ce8a04',
      'native_key' => 46,
      'filename' => 'modAction/e9b79c5a30d4e3f1a6cb5ee577f9c306.vehicle',
    ),
    34 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAction',
      'guid' => 'fabe3f9f69ff4d1f7a483864ced73ec7',
      'native_key' => 50,
      'filename' => 'modAction/dd993e1904d8841104df9ddf7c30f7eb.vehicle',
    ),
    35 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAction',
      'guid' => 'a4f85a33f5cd4e76716ade30af5d5677',
      'native_key' => 54,
      'filename' => 'modAction/deba06e4a59bc3c754cddd231a5c63a8.vehicle',
    ),
    36 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAction',
      'guid' => 'fac426527ed52eb30e832b6789b668d8',
      'native_key' => 55,
      'filename' => 'modAction/aad1271681e4c1e9f789a8459373ec0b.vehicle',
    ),
    37 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAction',
      'guid' => '3e21776f4428263f43eefbbbe14aba61',
      'native_key' => 56,
      'filename' => 'modAction/8cf04c442868bfe7faae70131fd544e9.vehicle',
    ),
    38 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAction',
      'guid' => '5727f1e796e2cd046d4c2ab2d0dfd65d',
      'native_key' => 62,
      'filename' => 'modAction/5d3d0598e01fec4bb8353da17e7cc36f.vehicle',
    ),
    39 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAction',
      'guid' => '93fc518be89dd9d246fc8f32b57e80b3',
      'native_key' => 64,
      'filename' => 'modAction/9a6d46427bc876d642a516cd99dfa797.vehicle',
    ),
    40 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAction',
      'guid' => 'b6fd83f06d4f013992088a0691f1114a',
      'native_key' => 67,
      'filename' => 'modAction/7236759dbfbcaf824de024ebf5967ec3.vehicle',
    ),
    41 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAction',
      'guid' => '7fd266f56443332926204d24f644f5b1',
      'native_key' => 70,
      'filename' => 'modAction/3a5d76a9a799ce02d73eb449a1ffc211.vehicle',
    ),
    42 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAction',
      'guid' => '4580d40acafbd2df902b2fd13417bfe2',
      'native_key' => 71,
      'filename' => 'modAction/eb0759675b70850c433eb7eb5696bdbd.vehicle',
    ),
    43 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAction',
      'guid' => '864e0f2651fde4413335e177d0c4147a',
      'native_key' => 75,
      'filename' => 'modAction/ffde0f950a991c3b69599e28d9f812c9.vehicle',
    ),
    44 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAction',
      'guid' => '0590d06c23766f6ee1eff7d7330af849',
      'native_key' => 82,
      'filename' => 'modAction/faa3bb5bf94a85e3f31d3cc4cb244685.vehicle',
    ),
    45 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAction',
      'guid' => '719379603cfaae74bd9af31747f839e0',
      'native_key' => 83,
      'filename' => 'modAction/c1a3297648dc5f75634f854c0e00948c.vehicle',
    ),
    46 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAction',
      'guid' => 'cba444319dec703389a78f106ba03c03',
      'native_key' => 84,
      'filename' => 'modAction/546d4b1b24cdd1a1e5272a45b24e3825.vehicle',
    ),
    47 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAction',
      'guid' => 'd455a0165c14011b0bac34d0e1a6116f',
      'native_key' => 85,
      'filename' => 'modAction/dfbf4dee610fb10ba77805b70b79283f.vehicle',
    ),
    48 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAction',
      'guid' => 'd721173213ca8371b7ab12fadc57e758',
      'native_key' => 101,
      'filename' => 'modAction/02ede92e40d8f149b46c36d6b08ec553.vehicle',
    ),
    49 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAction',
      'guid' => 'ed2a6e1c8d1aaa05fadc1c2dfda6505a',
      'native_key' => 102,
      'filename' => 'modAction/c801b7f511e46fe6fcc4ef374cc1e15c.vehicle',
    ),
    50 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAction',
      'guid' => '01545934a7a2af85cb3a205d73891d01',
      'native_key' => 103,
      'filename' => 'modAction/d9ee5d5fb27bbbfe02187fe0fdccc1cd.vehicle',
    ),
    51 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAction',
      'guid' => 'e88ad4444032b3c283bc5a64f56bab76',
      'native_key' => 104,
      'filename' => 'modAction/57fe1c1150b69472fcb0516aa663af15.vehicle',
    ),
    52 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAction',
      'guid' => '6f1834fc41f8d5171abc53afc8e18386',
      'native_key' => 105,
      'filename' => 'modAction/fe8a5c22dd4e5a15567e85dd0b6791ed.vehicle',
    ),
    53 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAction',
      'guid' => 'cbdf1e0e3637ed96a944f724f8a22614',
      'native_key' => 106,
      'filename' => 'modAction/8a5dfe3527db63c5bfe63857da50f17b.vehicle',
    ),
    54 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAction',
      'guid' => 'e5c8ce5a2401be6b70e07bf1c2853c26',
      'native_key' => 107,
      'filename' => 'modAction/2678fe3640e35367629b506b22440311.vehicle',
    ),
    55 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modMenu',
      'guid' => '7c53dea1f299d2ae3569529f97e9bf36',
      'native_key' => 'dashboard',
      'filename' => 'modMenu/ecd265c5706680a2c8f219bc66f55047.vehicle',
    ),
    56 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modMenu',
      'guid' => 'dc6301f50b86e32532deb072a999a79e',
      'native_key' => 'site',
      'filename' => 'modMenu/9d72396a13750260021e09bcec955582.vehicle',
    ),
    57 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modMenu',
      'guid' => 'ca4bdc53ab645bafadfc14f8fb3c8410',
      'native_key' => 'components',
      'filename' => 'modMenu/39959b3a1b4c6e6c89fecfbaaf6e940d.vehicle',
    ),
    58 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modMenu',
      'guid' => '36669e41f694ec704d3e74e297561688',
      'native_key' => 'security',
      'filename' => 'modMenu/d2bec4b196881870649c57e8eb35c039.vehicle',
    ),
    59 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modMenu',
      'guid' => '98b2dafab30a4c41db83d8e96574aeea',
      'native_key' => 'tools',
      'filename' => 'modMenu/95d7a5127bdb942cf52c98df04eab0c7.vehicle',
    ),
    60 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modMenu',
      'guid' => '73b7edb4c5741c4c1b32af2bc2e7d45d',
      'native_key' => 'reports',
      'filename' => 'modMenu/9c5b26bbe07cd06886c9f475f245dd77.vehicle',
    ),
    61 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modMenu',
      'guid' => '377dc237392906af36da109c3e4dea66',
      'native_key' => 'system',
      'filename' => 'modMenu/cc7cbffeae6cf48c550c713cc8c1c931.vehicle',
    ),
    62 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modMenu',
      'guid' => '06d3202d58bdd41d0ca38fb01084a33b',
      'native_key' => 'user',
      'filename' => 'modMenu/465e92d63913ef34f1d6bc16b19c76fd.vehicle',
    ),
    63 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modMenu',
      'guid' => '92e2591dc15b3fae90f80df1c443e5b1',
      'native_key' => 'support',
      'filename' => 'modMenu/d943eb4a8d7072f1ec36aa305a995fc5.vehicle',
    ),
    64 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modContentType',
      'guid' => 'aa34b80a33fb7f10987f42a873019093',
      'native_key' => 1,
      'filename' => 'modContentType/99fae1aa762a2eb9ae9073c05bbb4b4c.vehicle',
    ),
    65 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modContentType',
      'guid' => '742c1a11af57c9b08c573597bbf33dbc',
      'native_key' => 2,
      'filename' => 'modContentType/c3170265bf3137b6938e2919cab0ef16.vehicle',
    ),
    66 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modContentType',
      'guid' => 'e5729c8c3f7dc06345773100434d4978',
      'native_key' => 3,
      'filename' => 'modContentType/0ffc6a505596a4936c51bcebf1f2ea74.vehicle',
    ),
    67 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modContentType',
      'guid' => 'c48720f30f4c5b316acb8819da230251',
      'native_key' => 4,
      'filename' => 'modContentType/1f34f05285f2a195ed98b075c18b6a00.vehicle',
    ),
    68 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modContentType',
      'guid' => 'c0edc6f36244fe33abfb1b6adf7aacba',
      'native_key' => 5,
      'filename' => 'modContentType/dd4f963ed0d8239e170b0e2724953e13.vehicle',
    ),
    69 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modContentType',
      'guid' => '8dc939ce457b7834016f016314692803',
      'native_key' => 6,
      'filename' => 'modContentType/03fa2e69a2b8556e1b69024f588f7777.vehicle',
    ),
    70 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modContentType',
      'guid' => 'b4f8e7db7c703fa144e83f9696709fb4',
      'native_key' => 7,
      'filename' => 'modContentType/0c8b15ed8864a4d6979d91772e37aead.vehicle',
    ),
    71 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modClassMap',
      'guid' => '97897f401a62a4f900d4e1122477a09f',
      'native_key' => NULL,
      'filename' => 'modClassMap/1ab9562e8decc99ba5c8bac10964ccec.vehicle',
    ),
    72 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modClassMap',
      'guid' => '21bce69021e0134cb7079a52879f4c38',
      'native_key' => NULL,
      'filename' => 'modClassMap/ec35f09576965504579c5087f45c7534.vehicle',
    ),
    73 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modClassMap',
      'guid' => 'deb3ad7eed89878491f6fbb6f9e0ec91',
      'native_key' => NULL,
      'filename' => 'modClassMap/7e18b10d3d14935b2f67d514abfcc41c.vehicle',
    ),
    74 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modClassMap',
      'guid' => '75e4074fe3683db32882c85ad830fe31',
      'native_key' => NULL,
      'filename' => 'modClassMap/b0e63074f1ab32e9b9fc23d57341895f.vehicle',
    ),
    75 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modClassMap',
      'guid' => 'bb3f241b4fd4f40db70600f7ee5d6920',
      'native_key' => NULL,
      'filename' => 'modClassMap/1106fe32bb898f3db24caa76a3b76049.vehicle',
    ),
    76 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modClassMap',
      'guid' => 'a97ad2db101d0658039ef878dfd50654',
      'native_key' => NULL,
      'filename' => 'modClassMap/0316773179fe573936e7a16ab21e38ee.vehicle',
    ),
    77 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modClassMap',
      'guid' => 'cd1d3a5d2dcfa0c3204ea69e2adee0cd',
      'native_key' => NULL,
      'filename' => 'modClassMap/7589291fe86cc9cdce7694b5705c5349.vehicle',
    ),
    78 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modClassMap',
      'guid' => 'd343cf95d5f9e4a2701a8d7a44752d5e',
      'native_key' => NULL,
      'filename' => 'modClassMap/157948e7f2d8482d8e6ad8c8e081112c.vehicle',
    ),
    79 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modClassMap',
      'guid' => '58339eff4cf69c61222b046ae3b52f8a',
      'native_key' => NULL,
      'filename' => 'modClassMap/ad2afa0ce78cb83d5908ee32e7ef49ab.vehicle',
    ),
    80 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '8dc5976f64b6367d287f5684cd3a5036',
      'native_key' => 'OnPluginEventBeforeSave',
      'filename' => 'modEvent/284e9b0c9757400f2e30168e4613d1ac.vehicle',
    ),
    81 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'ed1df994688af7efdc6ff883019a912c',
      'native_key' => 'OnPluginEventSave',
      'filename' => 'modEvent/d45b510adc2d474e515951d284d65779.vehicle',
    ),
    82 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '514f99da4c6818c222032a2ab51dd9de',
      'native_key' => 'OnPluginEventBeforeRemove',
      'filename' => 'modEvent/fee946d2552fcda70a4bc2349c587775.vehicle',
    ),
    83 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '3e19602549aa0822b8d39c53817740ba',
      'native_key' => 'OnPluginEventRemove',
      'filename' => 'modEvent/adbf44188da47c273c43e4f2d42b0a94.vehicle',
    ),
    84 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'd74ee7527362dbccc147d49cc85ce963',
      'native_key' => 'OnResourceGroupSave',
      'filename' => 'modEvent/a24d0edc336df1e61c43c9abbf7a555c.vehicle',
    ),
    85 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '4f03632333576f265f76ababd901a810',
      'native_key' => 'OnResourceGroupBeforeSave',
      'filename' => 'modEvent/a1ddd0bcda743d36ddee713d58920cf1.vehicle',
    ),
    86 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'a853b64ed3131eb338b8ad94b57b37b6',
      'native_key' => 'OnResourceGroupRemove',
      'filename' => 'modEvent/ab7d237a96fc33ec3cc5c33ca5c8c349.vehicle',
    ),
    87 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '01644b379304aff2cac8cd5f2eb8f2db',
      'native_key' => 'OnResourceGroupBeforeRemove',
      'filename' => 'modEvent/a905c23fc7104b8fb592eeb6155a0a2e.vehicle',
    ),
    88 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'a077ec74bf691cba9db50a061e3b4540',
      'native_key' => 'OnSnippetBeforeSave',
      'filename' => 'modEvent/274b3b0a539d9b8973861d9492014c59.vehicle',
    ),
    89 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '25898ded3a5befab72dc734bda5bda90',
      'native_key' => 'OnSnippetSave',
      'filename' => 'modEvent/ee5183e6d3df6e6623f9efb9d22acaeb.vehicle',
    ),
    90 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'f49607f4b36348f76c5cd79ce8959e04',
      'native_key' => 'OnSnippetBeforeRemove',
      'filename' => 'modEvent/6b0444744ece82f5284f8d15543f9d8a.vehicle',
    ),
    91 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '9e58bf3d69e96f638ad2c9faa71bda40',
      'native_key' => 'OnSnippetRemove',
      'filename' => 'modEvent/3ea89e7df5e44df6bd3465d4d5cc6ac1.vehicle',
    ),
    92 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'fca26169ba4ad223c2bdcef3aae2f6a5',
      'native_key' => 'OnSnipFormPrerender',
      'filename' => 'modEvent/2a58d09335cea55bbdecc610e08d0c70.vehicle',
    ),
    93 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'cd4e94894132d330eee5c6561ae933e4',
      'native_key' => 'OnSnipFormRender',
      'filename' => 'modEvent/ff697888e43b4a5076d086205e225458.vehicle',
    ),
    94 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'c98f6165c81bc8315f957d1324c4f7fa',
      'native_key' => 'OnBeforeSnipFormSave',
      'filename' => 'modEvent/149db774800a8d03aa2bd6e12f8cc9cb.vehicle',
    ),
    95 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'abf5441a57cf07f82463b5ba52ba7572',
      'native_key' => 'OnSnipFormSave',
      'filename' => 'modEvent/024cdbe232d0427c44c8463d4f45520d.vehicle',
    ),
    96 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'd7b16115fa0f50a018b27f7d573c3271',
      'native_key' => 'OnBeforeSnipFormDelete',
      'filename' => 'modEvent/61125367337b5cb7b0ac3d327e3387c6.vehicle',
    ),
    97 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '9311f96982ce76b70857a7cd2133f950',
      'native_key' => 'OnSnipFormDelete',
      'filename' => 'modEvent/a7f5485b2f194a39ce42fd88e4a32145.vehicle',
    ),
    98 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'b2ca87b5662ab3299c099d2d6fdb4083',
      'native_key' => 'OnTemplateBeforeSave',
      'filename' => 'modEvent/72c25f2c05f4623c4ff9c59629e937db.vehicle',
    ),
    99 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '23e5b1e0d29fe847e2eccfab5f470b86',
      'native_key' => 'OnTemplateSave',
      'filename' => 'modEvent/6b39e14d2e84958d06ba6af1bb578ec9.vehicle',
    ),
    100 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '4fe7762e90d14dcc3cbb35adfbb6e1db',
      'native_key' => 'OnTemplateBeforeRemove',
      'filename' => 'modEvent/04c56093645eed44e5bb14a6577ca88f.vehicle',
    ),
    101 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '96820e630634f3529db23becaba93b48',
      'native_key' => 'OnTemplateRemove',
      'filename' => 'modEvent/97f1178da5974e21dd4c60af0dcc6689.vehicle',
    ),
    102 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'fca8da0e5f9262f6191d394487c02e27',
      'native_key' => 'OnTempFormPrerender',
      'filename' => 'modEvent/1e88cde08854ecb1dd208d39e274aa64.vehicle',
    ),
    103 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '3be3a306e475466d3c531b0c32f87a90',
      'native_key' => 'OnTempFormRender',
      'filename' => 'modEvent/b7f6d2fd8e7336b33ebb10d75075beea.vehicle',
    ),
    104 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '85bc1ad0f1733094bd0338bb574a6d6f',
      'native_key' => 'OnBeforeTempFormSave',
      'filename' => 'modEvent/cfbd242c90ebe91327a6b1bd5024633a.vehicle',
    ),
    105 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'd4f891ac01d47dd7c9bf2752dc9491d9',
      'native_key' => 'OnTempFormSave',
      'filename' => 'modEvent/d2420fc66799926cf71c6b5d6fa90f40.vehicle',
    ),
    106 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '52985f955ea7df3a02a3e47fe02d0a0d',
      'native_key' => 'OnBeforeTempFormDelete',
      'filename' => 'modEvent/0ba310d87d13cd090cc5a740313df540.vehicle',
    ),
    107 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'b718a2da26504cd9b4a451cd4ceb32ce',
      'native_key' => 'OnTempFormDelete',
      'filename' => 'modEvent/f6fe5e92f4492c673b7e8efa4476689b.vehicle',
    ),
    108 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'cca5ee0a99c2a221dd7b6f537a929427',
      'native_key' => 'OnTemplateVarBeforeSave',
      'filename' => 'modEvent/58875832b7aebda86c3ed2369c868bf8.vehicle',
    ),
    109 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '85ead4e324a05024d25768b46d708b29',
      'native_key' => 'OnTemplateVarSave',
      'filename' => 'modEvent/c3e075b85a040ce1f91d9439bdebe58d.vehicle',
    ),
    110 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '277c77f07f824444f869328f1c5b3d47',
      'native_key' => 'OnTemplateVarBeforeRemove',
      'filename' => 'modEvent/942e4e9bdb5dea2a3120428abeb5619f.vehicle',
    ),
    111 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'e227ec86a7ff449522aa235f42c126e9',
      'native_key' => 'OnTemplateVarRemove',
      'filename' => 'modEvent/318947fe8c18f37e18ece43d3fd68332.vehicle',
    ),
    112 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '195beac3292d65f3f63f59a2f868ff4d',
      'native_key' => 'OnTVFormPrerender',
      'filename' => 'modEvent/467f5dfeb05083175182f60ce35de33b.vehicle',
    ),
    113 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'd961cb72707bfa9a01b78614334a4139',
      'native_key' => 'OnTVFormRender',
      'filename' => 'modEvent/ed11b45c0c2b8b3571734c9db66798d9.vehicle',
    ),
    114 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '9de14f13b717fbd1f7fece16eeff774a',
      'native_key' => 'OnBeforeTVFormSave',
      'filename' => 'modEvent/20b0497f7686e4620cb7560e083e908c.vehicle',
    ),
    115 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'f999afded41db5428282aae83ebe3d95',
      'native_key' => 'OnTVFormSave',
      'filename' => 'modEvent/1e68cc26800cbd3c08cba7d23cf6232b.vehicle',
    ),
    116 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '186f122b0a3c7ae04b2481ca31f8dfec',
      'native_key' => 'OnBeforeTVFormDelete',
      'filename' => 'modEvent/bf2b123bbd72d8b5b6e473d1943548a0.vehicle',
    ),
    117 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '10806448b40b9c32c7dda953534a34d8',
      'native_key' => 'OnTVFormDelete',
      'filename' => 'modEvent/6b10e45952f7f22bf59a06ca9fedb677.vehicle',
    ),
    118 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'e3a40e3330ca64cb5c7ca050cc1ad036',
      'native_key' => 'OnTVInputRenderList',
      'filename' => 'modEvent/5a68404d65c192b139bb9c45a29a1836.vehicle',
    ),
    119 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '7f881ff2e881683a817fc1465c05fca1',
      'native_key' => 'OnTVInputPropertiesList',
      'filename' => 'modEvent/851e5ccac1db5a4d57b6b08c225d9404.vehicle',
    ),
    120 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'a22a1395952975f21524c9a7975fbdc0',
      'native_key' => 'OnTVOutputRenderList',
      'filename' => 'modEvent/ef77c233ad7e0ce9aca60ee3c1d01979.vehicle',
    ),
    121 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'f9d2c8173a540c0433f208dfb9531719',
      'native_key' => 'OnTVOutputRenderPropertiesList',
      'filename' => 'modEvent/44965b31454987413eadd2c6013a21f9.vehicle',
    ),
    122 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'ad1d969ef9ff0647466ffce013831a6e',
      'native_key' => 'OnUserGroupBeforeSave',
      'filename' => 'modEvent/e4308b0f044d594abb72407ef806efbb.vehicle',
    ),
    123 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '6a9b6df8c35dda2504a7c5715f907c67',
      'native_key' => 'OnUserGroupSave',
      'filename' => 'modEvent/c9a11677c35562887ef3e7c0b15a3fee.vehicle',
    ),
    124 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'a4ea1b490b9aec84bc386ae9a10ca414',
      'native_key' => 'OnUserGroupBeforeRemove',
      'filename' => 'modEvent/f94f380d890f62154e3ccff2151dcd76.vehicle',
    ),
    125 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'aebeff246c5cc224163643f82df2364e',
      'native_key' => 'OnUserGroupRemove',
      'filename' => 'modEvent/bf1a4bc4f2d60cbfcb116dd995a2bfe8.vehicle',
    ),
    126 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'e14eb837133cffccd22f25143653da32',
      'native_key' => 'OnBeforeUserGroupFormSave',
      'filename' => 'modEvent/1a3ace41da5b1be64c51c4f7de77ddc4.vehicle',
    ),
    127 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '562bf396a273a00af0aa85b29713b67c',
      'native_key' => 'OnUserGroupFormSave',
      'filename' => 'modEvent/101942b100bef3745b8a510f16b4948b.vehicle',
    ),
    128 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '81acd48de22d90afbb146265d55f22ee',
      'native_key' => 'OnBeforeUserGroupFormRemove',
      'filename' => 'modEvent/f26a7f15681575d96535c623f245f421.vehicle',
    ),
    129 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '32e8b8fe873889b4b8e1981247b9c668',
      'native_key' => 'OnBeforeUserGroupFormRemove',
      'filename' => 'modEvent/340e2dfe2769b92b0e9bf04ec976e66a.vehicle',
    ),
    130 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '41736c4ea3ebb748d974179197699e9c',
      'native_key' => 'OnDocFormPrerender',
      'filename' => 'modEvent/b8b996851b9b40b58636081f96075e11.vehicle',
    ),
    131 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'd3cbdff1867bbd9e3e3c28d5c42f1f13',
      'native_key' => 'OnDocFormRender',
      'filename' => 'modEvent/b076be0657e228d276bb41754b0f26b8.vehicle',
    ),
    132 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '78ed9e0b1d495115f685d38c607b0039',
      'native_key' => 'OnBeforeDocFormSave',
      'filename' => 'modEvent/54d2dc06f9d87010b6976a246f006866.vehicle',
    ),
    133 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'cb311d3f0ae6c840af4a019cf1f41cac',
      'native_key' => 'OnDocFormSave',
      'filename' => 'modEvent/f47aeae6dad14e48bdf29ec77678e176.vehicle',
    ),
    134 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '33f83bcabde4f0c7020769c07f18b47b',
      'native_key' => 'OnBeforeDocFormDelete',
      'filename' => 'modEvent/8ef1f52cf643db1f927e6bfb0b27c96d.vehicle',
    ),
    135 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'c0439924c8b2b72b366bd7681cbd5a0d',
      'native_key' => 'OnDocFormDelete',
      'filename' => 'modEvent/28028c6aefd605f5d315786b1e39c79d.vehicle',
    ),
    136 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '8b1fbe6fd1fc436b9a977e99d0e0f93a',
      'native_key' => 'OnDocPublished',
      'filename' => 'modEvent/e77fa2f6836fa3a4a70922c85596eada.vehicle',
    ),
    137 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'ed8c837b782fea1f5b6260c35d3a2335',
      'native_key' => 'OnDocUnPublished',
      'filename' => 'modEvent/94e9b26478d0ab22dee0c0dda38f4ae6.vehicle',
    ),
    138 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'e3691757ee34258b9689ca84cd04f42c',
      'native_key' => 'OnBeforeEmptyTrash',
      'filename' => 'modEvent/4865b2c0005f87a4d5bf8046541a9791.vehicle',
    ),
    139 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '770d9c7ba91e570d10eefe4c79a675b8',
      'native_key' => 'OnEmptyTrash',
      'filename' => 'modEvent/d75b2a8f1622748ed87b7fd55c53e20a.vehicle',
    ),
    140 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '035a9741bacb080f30b7b639bc0ed9f5',
      'native_key' => 'OnResourceTVFormPrerender',
      'filename' => 'modEvent/74dd7f773715c30e37f314e9b1543f32.vehicle',
    ),
    141 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'baec800d314e1a413cceae15337815d3',
      'native_key' => 'OnResourceTVFormRender',
      'filename' => 'modEvent/543385a4ad7f5f00e66f792f9781c1c6.vehicle',
    ),
    142 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'a054a5dbf12f6ca794c497ece124e535',
      'native_key' => 'OnResourceDelete',
      'filename' => 'modEvent/933bdbf77751aae4319ff57cf05a55e4.vehicle',
    ),
    143 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '2c1abb3678d36b80876ed78dffce0ffe',
      'native_key' => 'OnResourceUndelete',
      'filename' => 'modEvent/028c62e2e2bca017276adf5d57f4a813.vehicle',
    ),
    144 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '3408f7c9240eb193f834f14e87fb35e7',
      'native_key' => 'OnResourceBeforeSort',
      'filename' => 'modEvent/a583eef3d2612f0a0533eeb5ee3721db.vehicle',
    ),
    145 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '15315cab49c5a6e97486df1ae08b45d7',
      'native_key' => 'OnResourceSort',
      'filename' => 'modEvent/22822828c0b9df6b5f0adabb01b018e1.vehicle',
    ),
    146 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'f4b595fff107ba61cb1e6066910a536c',
      'native_key' => 'OnResourceDuplicate',
      'filename' => 'modEvent/45ef9c4377633b229ca9de0a2d4af56f.vehicle',
    ),
    147 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'ba95df8821044295f3e35aeb1a3a4317',
      'native_key' => 'OnResourceToolbarLoad',
      'filename' => 'modEvent/208f0c024cc9ec48e48ee46176f3bf3d.vehicle',
    ),
    148 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'db4bd411c20de9be93708b97f8782de6',
      'native_key' => 'OnResourceRemoveFromResourceGroup',
      'filename' => 'modEvent/fc5c6242a001150ea73f7273aaf9d3a4.vehicle',
    ),
    149 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '290eed329e5f870d9307ea82c788aa1a',
      'native_key' => 'OnResourceAddToResourceGroup',
      'filename' => 'modEvent/cbe642bb916ff84fb2a39d3d331c9119.vehicle',
    ),
    150 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '5a805f8a25aa8028ee0b6afef90664ac',
      'native_key' => 'OnRichTextEditorRegister',
      'filename' => 'modEvent/29d8bc47b20ea7fc63938be21b28e966.vehicle',
    ),
    151 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '371d66b8d494e76c30433813e8b09e12',
      'native_key' => 'OnRichTextEditorInit',
      'filename' => 'modEvent/1561a9c5a7e4639f647a14550596b583.vehicle',
    ),
    152 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '137a8946213d617072e6a13721eaa093',
      'native_key' => 'OnRichTextBrowserInit',
      'filename' => 'modEvent/58e2626e75bfa99b643a31c21ea60d3b.vehicle',
    ),
    153 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'a45e891b6abf068d347ae35448c2bcb9',
      'native_key' => 'OnWebLogin',
      'filename' => 'modEvent/1b8da2afc4d3f882a74fbb956f84d3ef.vehicle',
    ),
    154 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '737ffb3f07409a4c2c13a474587039e6',
      'native_key' => 'OnBeforeWebLogout',
      'filename' => 'modEvent/242c726e8c8b2a7cbac7fc36598d1a2a.vehicle',
    ),
    155 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '6f26ee78ce3b8a4b552680811be130f4',
      'native_key' => 'OnWebLogout',
      'filename' => 'modEvent/0e5cdda5b8c0d822ca9c20c9ff2190b0.vehicle',
    ),
    156 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'df21f08b5cb64ba4189fd4ddebe76b6a',
      'native_key' => 'OnManagerLogin',
      'filename' => 'modEvent/ed5f91b71bf9323dc76d27c52f026d5e.vehicle',
    ),
    157 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '9d4f3bb64db5b4dfe2ea86c9eddbc746',
      'native_key' => 'OnBeforeManagerLogout',
      'filename' => 'modEvent/a871ab573557c6a140ee258a69505502.vehicle',
    ),
    158 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '790508b18163d8cc12c6cb315318ab1a',
      'native_key' => 'OnManagerLogout',
      'filename' => 'modEvent/dc156e3f24aed84c41e8e1537dd32ad1.vehicle',
    ),
    159 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '7d29f6ddb47bc4943de59d9cdf4d8382',
      'native_key' => 'OnBeforeWebLogin',
      'filename' => 'modEvent/035f3d0ec45617def80d5abbaef086c3.vehicle',
    ),
    160 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '3a42a70a1c9ca95142d825065be64b81',
      'native_key' => 'OnWebAuthentication',
      'filename' => 'modEvent/7ba6d67e7d6d6f3ddc763e29bee5e89d.vehicle',
    ),
    161 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'bede71141941f124a1a9de1b3fa040a1',
      'native_key' => 'OnBeforeManagerLogin',
      'filename' => 'modEvent/0f317e40878f429d24bf8bd03b76b2cb.vehicle',
    ),
    162 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'bb266efc68f85bf771a346790b937922',
      'native_key' => 'OnManagerAuthentication',
      'filename' => 'modEvent/e4fbcafd9c947af1fd0ac4faf2094a30.vehicle',
    ),
    163 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '0993a74ac3f696267f32363a3c049bba',
      'native_key' => 'OnManagerLoginFormRender',
      'filename' => 'modEvent/7a1e6422fbbbde75512e665057ce8e19.vehicle',
    ),
    164 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '65ddd16238bd4b3ee0fd46dcc3eae6d0',
      'native_key' => 'OnManagerLoginFormPrerender',
      'filename' => 'modEvent/65a65aff59bb16a389301fd48b6176e1.vehicle',
    ),
    165 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'b4daa113d4d1004fdc85e67427e26474',
      'native_key' => 'OnPageUnauthorized',
      'filename' => 'modEvent/a39245c7b41182dfff2c4d7b6346fe2f.vehicle',
    ),
    166 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'f483473e1311732459835f3eeee1c207',
      'native_key' => 'OnUserFormPrerender',
      'filename' => 'modEvent/816fa42542bfecf8824e2d5de20a51df.vehicle',
    ),
    167 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '9fc6b5462c750842c3c2524f1f86ae11',
      'native_key' => 'OnUserFormRender',
      'filename' => 'modEvent/262a486f45a449029fd7db1b62e6cf06.vehicle',
    ),
    168 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'b89368f1042d8c6ea5c6a0b7366c3187',
      'native_key' => 'OnBeforeUserFormSave',
      'filename' => 'modEvent/724bd585e3a86a0c9b7c9c9b8a50e713.vehicle',
    ),
    169 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'ad0260d59e1fdc4be87b6d48c4451301',
      'native_key' => 'OnUserFormSave',
      'filename' => 'modEvent/a1abfac9faf46369533d6df36509e651.vehicle',
    ),
    170 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'a8296e481e32995e1e9eeb5c7ce26629',
      'native_key' => 'OnBeforeUserFormDelete',
      'filename' => 'modEvent/8546d093edab56f6334c6e552977f6b4.vehicle',
    ),
    171 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '67129382b0997d6ec8721c6abd5e7e71',
      'native_key' => 'OnUserFormDelete',
      'filename' => 'modEvent/ef3f71f854416cb2af23a1470a05ec83.vehicle',
    ),
    172 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '3a20faf7fd75940a5e2a4294a9587ca5',
      'native_key' => 'OnUserNotFound',
      'filename' => 'modEvent/deef0ed2471dbd26e0fa040cf2ad4784.vehicle',
    ),
    173 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '525b7f64e5f2cf6112671dc5e1250e76',
      'native_key' => 'OnBeforeUserActivate',
      'filename' => 'modEvent/e5530ed29f06e00cfcc6fca8ed39ba0b.vehicle',
    ),
    174 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '0c497ad1a23b99f002e287a873858c50',
      'native_key' => 'OnUserActivate',
      'filename' => 'modEvent/0307daa6670e7795ddd184b811a890fd.vehicle',
    ),
    175 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '8834004e457650d3194e3d3754fd5efb',
      'native_key' => 'OnBeforeUserDeactivate',
      'filename' => 'modEvent/5bbc9a10a9d8eac1be4ac731745dca36.vehicle',
    ),
    176 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '50bcb1ddc3aab046dc75c768ca54d3ed',
      'native_key' => 'OnUserDeactivate',
      'filename' => 'modEvent/562a14e0b3adf76c9b63f3582f4b62c1.vehicle',
    ),
    177 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '0321c8e561fb429eda4b4b5b2b8ca889',
      'native_key' => 'OnBeforeUserDuplicate',
      'filename' => 'modEvent/56dfda2a34cdda5fcc5dc5c29ab66ec8.vehicle',
    ),
    178 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'b9b6a979928400cd3894cbc8f103e1f4',
      'native_key' => 'OnUserDuplicate',
      'filename' => 'modEvent/49f7a47dd5f4fb9745aacd615d086f75.vehicle',
    ),
    179 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '11172779335b49d943c69b100867549b',
      'native_key' => 'OnUserChangePassword',
      'filename' => 'modEvent/da210c7340eda6a2afa351f57c31a44f.vehicle',
    ),
    180 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'f8ff264eed94bc14e48bd463d20be13a',
      'native_key' => 'OnUserBeforeRemove',
      'filename' => 'modEvent/1ce9a6c982084ec99e9d21ccb74a36f1.vehicle',
    ),
    181 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '0d551e764e0a19bacf561e3254f65cf7',
      'native_key' => 'OnUserBeforeSave',
      'filename' => 'modEvent/94d71df08cca0101f7c109450cc7b51d.vehicle',
    ),
    182 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'daa30bf133d13a01bab5da0601ea1449',
      'native_key' => 'OnUserSave',
      'filename' => 'modEvent/22dd54e33d4c703efaece9d71dea8f2f.vehicle',
    ),
    183 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'f32dfc075106b870e5cb1a57552950a0',
      'native_key' => 'OnUserRemove',
      'filename' => 'modEvent/5510368318f2d7f4aa4570181a10ee31.vehicle',
    ),
    184 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '0dffade85a8cf0b787c77368309671b4',
      'native_key' => 'OnUserBeforeAddToGroup',
      'filename' => 'modEvent/be444d0a14335e2e0497fe4b615331b8.vehicle',
    ),
    185 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'b145faeab4d91399867808c8e7b5e853',
      'native_key' => 'OnUserAddToGroup',
      'filename' => 'modEvent/0550f27d03318cd957a8ba05a7cd7fa7.vehicle',
    ),
    186 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '8085d0798d4e30a2dfa5e1104dcbcf5a',
      'native_key' => 'OnUserBeforeRemoveFromGroup',
      'filename' => 'modEvent/a07d1515c009b0a05e793b5e29f16fb1.vehicle',
    ),
    187 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'e95816fa2becd86efe55fda8052806f6',
      'native_key' => 'OnUserRemoveFromGroup',
      'filename' => 'modEvent/3bf53c49e184ef53f3c6ed365d40134b.vehicle',
    ),
    188 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'c3dd1bbe08bcb8392309b464f34b84fc',
      'native_key' => 'OnWebPagePrerender',
      'filename' => 'modEvent/ab0624e32f3b9b209031cad763799b55.vehicle',
    ),
    189 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '2899e09719d1f36396258b1d95b61915',
      'native_key' => 'OnBeforeCacheUpdate',
      'filename' => 'modEvent/53679c7dcab921c6b99699ae6217461a.vehicle',
    ),
    190 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'eb9cb0920b86eb6a6397b6c13fee2120',
      'native_key' => 'OnCacheUpdate',
      'filename' => 'modEvent/ccf3bde55aab52add668624debf1bc03.vehicle',
    ),
    191 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '8fa22655fee277496b771e10b8d9f7e0',
      'native_key' => 'OnLoadWebPageCache',
      'filename' => 'modEvent/3d41d7c1aca64bb93e281c0d77c4e7f0.vehicle',
    ),
    192 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'e028b0083c427e290735e1e454dda7ae',
      'native_key' => 'OnBeforeSaveWebPageCache',
      'filename' => 'modEvent/1f7509d17d57c43d27edabf3dff0c226.vehicle',
    ),
    193 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'c6deb201c2ed41331f126ffaca8f33f9',
      'native_key' => 'OnSiteRefresh',
      'filename' => 'modEvent/606d767fce3258e4913dce79a66ed817.vehicle',
    ),
    194 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'c2202a7b17f005c444392d812fd64dab',
      'native_key' => 'OnFileManagerUpload',
      'filename' => 'modEvent/d0d30ee3bc0536ee25e64521aeafbe36.vehicle',
    ),
    195 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '18abc5af1cbf573e76a841afe8d271a4',
      'native_key' => 'OnFileCreateFormPrerender',
      'filename' => 'modEvent/1ab589dc8d5857c90a1daea975b14018.vehicle',
    ),
    196 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '5230e87c72c6bd64686d2177de0fe928',
      'native_key' => 'OnFileEditFormPrerender',
      'filename' => 'modEvent/28e67d24e49e12698f52b89eb122a8d4.vehicle',
    ),
    197 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '5f3f64e1fad3dba4ee88be11b7c8f87e',
      'native_key' => 'OnManagerPageInit',
      'filename' => 'modEvent/22456c5c44e4218d8bff52ff72b2bd26.vehicle',
    ),
    198 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '182234f1fb94fdb57f78f05019aecf13',
      'native_key' => 'OnManagerPageBeforeRender',
      'filename' => 'modEvent/454ecb3dd46f2f5d5a5773890eb3c9fe.vehicle',
    ),
    199 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '95f12b6e13ccefd54b91bd46f21c3e3f',
      'native_key' => 'OnManagerPageAfterRender',
      'filename' => 'modEvent/8ac33e50dfe40a5289124b044a355d29.vehicle',
    ),
    200 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'a10d189cdd9e7ffe58b24a114b806faa',
      'native_key' => 'OnWebPageInit',
      'filename' => 'modEvent/2853c23df24139638d5ef0a40f213d68.vehicle',
    ),
    201 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'a5eadcece1ebfa30e385382847aeaf5e',
      'native_key' => 'OnLoadWebDocument',
      'filename' => 'modEvent/2427c3527d44d8b2cbe91052f8cbbde2.vehicle',
    ),
    202 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '69b56ed3a6d91f59daad3f5bc1a60abe',
      'native_key' => 'OnParseDocument',
      'filename' => 'modEvent/1c228828953b233cb540c5756df9efc1.vehicle',
    ),
    203 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'd2a271c532be57833db88c9c83df42f1',
      'native_key' => 'OnWebPageComplete',
      'filename' => 'modEvent/750d03740c706bd5eec7e89f4cd9c729.vehicle',
    ),
    204 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '3e1bda45af3f199e9add9e054f08d1b9',
      'native_key' => 'OnBeforeManagerPageInit',
      'filename' => 'modEvent/8c03dd99e4bc5864c4e88907234db116.vehicle',
    ),
    205 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '29cea847f25dac5dd4e2eb73eb238bb7',
      'native_key' => 'OnPageNotFound',
      'filename' => 'modEvent/67484d08f991696538a0514fc41c6ee2.vehicle',
    ),
    206 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'c0c9ad7f432e009b9dbf5472dff7102c',
      'native_key' => 'OnHandleRequest',
      'filename' => 'modEvent/f45f2f250195a244195fe66f8eec7ffd.vehicle',
    ),
    207 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'ae50032847bdd06af45e3eaef85ea2c7',
      'native_key' => 'OnSiteSettingsRender',
      'filename' => 'modEvent/7c82dc46dc1b48746fa445020a96ecca.vehicle',
    ),
    208 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '8fe90bc890bc6d5b56af9363ea00e424',
      'native_key' => 'OnInitCulture',
      'filename' => 'modEvent/61a70e9974adc9442de5dda761436709.vehicle',
    ),
    209 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '4f9d2ec3537542642caf3b8cb9ae39ad',
      'native_key' => 'OnCategorySave',
      'filename' => 'modEvent/34468dae659242deef8b0c64b7cc4675.vehicle',
    ),
    210 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '307a0004656d9a7f9a88bf8ea284cb76',
      'native_key' => 'OnCategoryBeforeSave',
      'filename' => 'modEvent/ffc5bf6eba517f33a54dae6e64045cd3.vehicle',
    ),
    211 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '840e484ffafee1cf8a120274af09a6bf',
      'native_key' => 'OnCategoryRemove',
      'filename' => 'modEvent/7f1108bcfe66a9373a4bf68a0c1f46ce.vehicle',
    ),
    212 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'e46bfcb37fdd6bc909ff0f00db52de68',
      'native_key' => 'OnCategoryBeforeRemove',
      'filename' => 'modEvent/ba3d351aeccd160c56aafa4ffa02e560.vehicle',
    ),
    213 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '2f18f9abd705e0b3f41057b3c52b92ca',
      'native_key' => 'OnChunkSave',
      'filename' => 'modEvent/f3b75fbb50d9040cb64476b016a01bf6.vehicle',
    ),
    214 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'fed1f6999ed24c0672fd8c1843c60d32',
      'native_key' => 'OnChunkBeforeSave',
      'filename' => 'modEvent/123a7c245728eed43b9265c45d6914d4.vehicle',
    ),
    215 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'dd66728870c2b0cb55c5f996b25747e8',
      'native_key' => 'OnChunkRemove',
      'filename' => 'modEvent/ba1470b359130d9f3ea3a25095217bd1.vehicle',
    ),
    216 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '363a6bcfe07badc6cf5a0bc2d344622e',
      'native_key' => 'OnChunkBeforeRemove',
      'filename' => 'modEvent/d93f3e5aef0794e4f82ff74fb9727146.vehicle',
    ),
    217 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'eeec0245bc1e5cd1679d450607514bc6',
      'native_key' => 'OnChunkFormPrerender',
      'filename' => 'modEvent/f7651eb3444833497dd86d2d58643ec6.vehicle',
    ),
    218 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '52a61355e1b0e90daea5a9bd6e9abcfd',
      'native_key' => 'OnChunkFormRender',
      'filename' => 'modEvent/e7df613698cec7e9574c44bb387ca37e.vehicle',
    ),
    219 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '286dd08cd54c32e9e01b4f5ee0bb00b7',
      'native_key' => 'OnBeforeChunkFormSave',
      'filename' => 'modEvent/5d07388cb3ed2948ce0898c99edaf45a.vehicle',
    ),
    220 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'a8c23f97018df8569f2eeb287a927725',
      'native_key' => 'OnChunkFormSave',
      'filename' => 'modEvent/65e44ce54e8e519039cd1c1ab2bd90f3.vehicle',
    ),
    221 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '84028cb59b3f947b9df1b8efc61645b2',
      'native_key' => 'OnBeforeChunkFormDelete',
      'filename' => 'modEvent/7292953fc29daf28cac456a52f0e946b.vehicle',
    ),
    222 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '89215a98a5a46545b6f473b71a3fd4f9',
      'native_key' => 'OnChunkFormDelete',
      'filename' => 'modEvent/6ee719b52d6c59a90484c2e178cac3a8.vehicle',
    ),
    223 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '446ceaed88833c0b29426f137db2307a',
      'native_key' => 'OnContextSave',
      'filename' => 'modEvent/85ecdb6278043712a84128fce1080e1d.vehicle',
    ),
    224 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'f0e99ca276b77082b05d0c79bdfad4a5',
      'native_key' => 'OnContextBeforeSave',
      'filename' => 'modEvent/d2ea3a526f7fb7f1ed8015152650afa9.vehicle',
    ),
    225 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'dc90a7204b5e538985d7de210ff531ed',
      'native_key' => 'OnContextRemove',
      'filename' => 'modEvent/9a7f56ba37a63b954a221fc60edf816c.vehicle',
    ),
    226 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '88bb3aa3dd448dd9575d734f4e95d800',
      'native_key' => 'OnContextBeforeRemove',
      'filename' => 'modEvent/736a0d11b2150e380675e9b01361c884.vehicle',
    ),
    227 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'dde1b1c848c6d23795ad4348560a2c9f',
      'native_key' => 'OnContextFormPrerender',
      'filename' => 'modEvent/468ddd206f9f5f7c8fbcbd97437d56ee.vehicle',
    ),
    228 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '73373145ba0c617bdeb96d33b3aedd49',
      'native_key' => 'OnContextFormRender',
      'filename' => 'modEvent/01cfe60acbc7e958e38851126c0e2d0c.vehicle',
    ),
    229 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '22ec1e5558df802348a9227175ec1c32',
      'native_key' => 'OnPluginSave',
      'filename' => 'modEvent/f794d561e4c3f7fb041a803baf45d7c8.vehicle',
    ),
    230 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '29ecc4feacbfe71db4f525c2f0294d33',
      'native_key' => 'OnPluginBeforeSave',
      'filename' => 'modEvent/eceaf2a4d3c8edc249e8de29c1a93343.vehicle',
    ),
    231 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '478cca9978a56ec04336cc620cde67aa',
      'native_key' => 'OnPluginRemove',
      'filename' => 'modEvent/5817fbba0f92b3f6827e1605867daa68.vehicle',
    ),
    232 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '962dde74314ee649b311db3ea4c20de5',
      'native_key' => 'OnPluginBeforeRemove',
      'filename' => 'modEvent/173693758414a0290faa13cf6afab610.vehicle',
    ),
    233 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'f764e3eeac802b4e1d9005a679d9af10',
      'native_key' => 'OnPluginFormPrerender',
      'filename' => 'modEvent/23dd1e06b90ce0ff4eecc3aac9ac9418.vehicle',
    ),
    234 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'c94af22d80763ee9b42f5cbe164be703',
      'native_key' => 'OnPluginFormRender',
      'filename' => 'modEvent/71e8357bbe543c30225264a3c0e1765a.vehicle',
    ),
    235 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '1dafb7e560f82807658d4964e1904819',
      'native_key' => 'OnBeforePluginFormSave',
      'filename' => 'modEvent/3b2aecdf2eaa1e9c839b39a554663af5.vehicle',
    ),
    236 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'c93ad4f24a622f8a9cdfecd263a4e913',
      'native_key' => 'OnPluginFormSave',
      'filename' => 'modEvent/97d6bf06056c0b931a0ec72e4264a4ff.vehicle',
    ),
    237 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '387e3d59dd407bca6e5bb366e9bea8db',
      'native_key' => 'OnBeforePluginFormDelete',
      'filename' => 'modEvent/0ec7846881900b8041f849a2e3bf87e6.vehicle',
    ),
    238 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'b46cee73b5bbdff3aedc8beae579f014',
      'native_key' => 'OnPluginFormDelete',
      'filename' => 'modEvent/d6c63326bef831330008977e63a8e957.vehicle',
    ),
    239 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '64bec770c58640c053c6c066278297e6',
      'native_key' => 'OnPropertySetSave',
      'filename' => 'modEvent/71de4680ae6870bfe65869191c5208c5.vehicle',
    ),
    240 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '10d811f828519fb2ee3b00dfdda9d535',
      'native_key' => 'OnPropertySetBeforeSave',
      'filename' => 'modEvent/07c7de8780a7b2c8ea82cb6e173ab376.vehicle',
    ),
    241 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'fd5b37be565fa7136ca761bc51eadedf',
      'native_key' => 'OnPropertySetRemove',
      'filename' => 'modEvent/d1b3206487cfcfdcaa8cfc4d8f1149b2.vehicle',
    ),
    242 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'f369ea7230a341e3497bb36d6fa9793f',
      'native_key' => 'OnPropertySetBeforeRemove',
      'filename' => 'modEvent/3fccf7e2fa23058a87423ecbee6412cd.vehicle',
    ),
    243 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '3ed61bcbcd1962754610cdafbd31aa6b',
      'native_key' => 'OnMediaSourceBeforeFormDelete',
      'filename' => 'modEvent/c4af968fbc7651c5e4fe953e995b3c77.vehicle',
    ),
    244 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'e3f993c1a31bef4d21af066cc5dd4fb5',
      'native_key' => 'OnMediaSourceBeforeFormSave',
      'filename' => 'modEvent/ff0a654a5f7400c3c9d299679bf82dda.vehicle',
    ),
    245 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '750d659e7ccedf929073fbfc3aff428f',
      'native_key' => 'OnMediaSourceGetProperties',
      'filename' => 'modEvent/94a75aa362b37779ece6dbf5dbd79393.vehicle',
    ),
    246 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'ae80226a9f322c4433ec6f5678e58e06',
      'native_key' => 'OnMediaSourceFormDelete',
      'filename' => 'modEvent/33b221772fc4aa8a00b3f1e5e301a749.vehicle',
    ),
    247 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '5ee8ad8fd86b0ea7b1a370ebdf1d0dce',
      'native_key' => 'OnMediaSourceFormSave',
      'filename' => 'modEvent/6797a8287555d8bb0b106fca9899a55f.vehicle',
    ),
    248 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '5a2263fd39f938ee844d156f02cab4e5',
      'native_key' => 'OnMediaSourceDuplicate',
      'filename' => 'modEvent/d3ef71d328e568fe161a3f8232d1b786.vehicle',
    ),
    249 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '61414854b73add56d2e4057d024064a9',
      'native_key' => 'access_category_enabled',
      'filename' => 'modSystemSetting/a58140e49ad332f3b1cfebd6ef43566e.vehicle',
    ),
    250 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '6382af573a5b1a3fbe55ddf95f5c83ac',
      'native_key' => 'access_context_enabled',
      'filename' => 'modSystemSetting/e29d0bb16bf7775b4c02f7d277f4aa32.vehicle',
    ),
    251 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'cbf0c4f738c6045d46a1f22aff188c28',
      'native_key' => 'access_resource_group_enabled',
      'filename' => 'modSystemSetting/d1a69dfb1577f85945a68d09ab00eb80.vehicle',
    ),
    252 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'f379f734369b1fe8eedd7e018e55760c',
      'native_key' => 'allow_forward_across_contexts',
      'filename' => 'modSystemSetting/17663e9f4b346405dd8a24db1d0a6ee0.vehicle',
    ),
    253 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'ce71095c02b257c40fd7b1fd503607e7',
      'native_key' => 'allow_manager_login_forgot_password',
      'filename' => 'modSystemSetting/0c692ca0454ef62572beb12d2198644c.vehicle',
    ),
    254 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '68f12798ead4897b6412b45ba43b280a',
      'native_key' => 'allow_multiple_emails',
      'filename' => 'modSystemSetting/6237223adedda0fed9bb4d89ccea15c9.vehicle',
    ),
    255 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '16ab728ea3c3e59de49051822a015bd3',
      'native_key' => 'allow_tags_in_post',
      'filename' => 'modSystemSetting/04654a0b2e7a5d0d0ba1177c8f61984a.vehicle',
    ),
    256 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '05503ff274838fe65d2c2caf13b95c12',
      'native_key' => 'archive_with',
      'filename' => 'modSystemSetting/fc69b2e8e2727e685b2df49dacbb5ee3.vehicle',
    ),
    257 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'd372700df31073be73697d9443348722',
      'native_key' => 'auto_menuindex',
      'filename' => 'modSystemSetting/f1514599327851c50ebda68848a6fee0.vehicle',
    ),
    258 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'ded700217a26902bd72b829310566fd4',
      'native_key' => 'auto_check_pkg_updates',
      'filename' => 'modSystemSetting/9e8e79a9273169807ba6284518659463.vehicle',
    ),
    259 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'c26eb08b89d3cbc86ab49fcdaa8e48ac',
      'native_key' => 'auto_check_pkg_updates_cache_expire',
      'filename' => 'modSystemSetting/d0cf905d4fe423c499b01733ebfa7dea.vehicle',
    ),
    260 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'a146e6bca1bd8a48f1d04f857f713bfb',
      'native_key' => 'automatic_alias',
      'filename' => 'modSystemSetting/2721bd623a890d772d4bd9bcf387536f.vehicle',
    ),
    261 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'b2fb49416fd29f02a4a4ab7488e72838',
      'native_key' => 'base_help_url',
      'filename' => 'modSystemSetting/615e1c866cc8e029106a7122701838f7.vehicle',
    ),
    262 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '2c7b154ec66c7a707dfc86a9ca4b5be8',
      'native_key' => 'blocked_minutes',
      'filename' => 'modSystemSetting/2644c5bbcead5ed4493f8296d242ede9.vehicle',
    ),
    263 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'd955dff7e54e5eeebee10eb74b716bab',
      'native_key' => 'cache_action_map',
      'filename' => 'modSystemSetting/0c1706e88c180ef51528f5e4e1b7613a.vehicle',
    ),
    264 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '1ecdcd4788a94cb73c11bfbe930213b8',
      'native_key' => 'cache_alias_map',
      'filename' => 'modSystemSetting/0f19caeeb1968de8378821ea0e68e39e.vehicle',
    ),
    265 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'dd75d05e4da4c3c4b64d8e58b3d874dd',
      'native_key' => 'cache_context_settings',
      'filename' => 'modSystemSetting/914d2f662a425ba0f8fb058a51808f43.vehicle',
    ),
    266 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '4b69cb613f8338d0d8bcd79b134a2f09',
      'native_key' => 'cache_db',
      'filename' => 'modSystemSetting/ad6179e9cdcd06d975612f9dae137a77.vehicle',
    ),
    267 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '8550ec76b954d09cc282eb47476cdaf9',
      'native_key' => 'cache_db_expires',
      'filename' => 'modSystemSetting/49b952cabb7c1d2e959817fc930652d1.vehicle',
    ),
    268 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '4e13d1e6859dcd2a3d2de5a9f711c4f0',
      'native_key' => 'cache_db_session',
      'filename' => 'modSystemSetting/4b5d4a51e7b3e6528d2926fd4f8da232.vehicle',
    ),
    269 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '7788e2985a5d352c91cb58d9a8d2e941',
      'native_key' => 'cache_db_session_lifetime',
      'filename' => 'modSystemSetting/e505b942fdb1b618f064f1f53e065e32.vehicle',
    ),
    270 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'da5a67693fab504c92bc5665a9fe53fd',
      'native_key' => 'cache_default',
      'filename' => 'modSystemSetting/b16d14162ce8ffd493566e53818b3a5e.vehicle',
    ),
    271 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '780c449a7e6d80ce84a8559c2a04ee99',
      'native_key' => 'cache_disabled',
      'filename' => 'modSystemSetting/5017a8f9ff99b112ef9d3bad319732ae.vehicle',
    ),
    272 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'b7410138dc9c2a55a157f87ecf874671',
      'native_key' => 'cache_expires',
      'filename' => 'modSystemSetting/a7bde253233914cf86b74339e7a21330.vehicle',
    ),
    273 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'c72e09e437776d957a51da33733c3403',
      'native_key' => 'cache_format',
      'filename' => 'modSystemSetting/6d1ed788ff338907dbeae079ac7fd326.vehicle',
    ),
    274 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '751e040eb4609d0555bf0f5336bf56d8',
      'native_key' => 'cache_handler',
      'filename' => 'modSystemSetting/14e9fc444821fb40c319afd4ab9074a0.vehicle',
    ),
    275 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '99cef1666aaa82ef9bd51167033414ea',
      'native_key' => 'cache_lang_js',
      'filename' => 'modSystemSetting/86a3252d88c24765c7117ca9cfa4e55c.vehicle',
    ),
    276 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '9db10dcf4995e8d5772f5c4f5303ff20',
      'native_key' => 'cache_lexicon_topics',
      'filename' => 'modSystemSetting/bdf53ec29ced14a0807d83ff1b5b6013.vehicle',
    ),
    277 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '92fc4dbbf1d6dab54fc17865568d078a',
      'native_key' => 'cache_noncore_lexicon_topics',
      'filename' => 'modSystemSetting/e49ed76dc48a8fd08ab3f9021212079a.vehicle',
    ),
    278 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '52b01908f24ea8288c41229f4255157d',
      'native_key' => 'cache_resource',
      'filename' => 'modSystemSetting/dc843633fca3af633928a4f929a9e47b.vehicle',
    ),
    279 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '4095c58013859198dd09529c05122725',
      'native_key' => 'cache_resource_expires',
      'filename' => 'modSystemSetting/048d17dc05736e9ba56b2896e9ddb668.vehicle',
    ),
    280 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '6386b7179b8bf9dd21ee46e268f03aed',
      'native_key' => 'cache_scripts',
      'filename' => 'modSystemSetting/ee8aead814d9c09048cc736f12130547.vehicle',
    ),
    281 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '7477138ae213d5868ebb8ffc25dde015',
      'native_key' => 'cache_system_settings',
      'filename' => 'modSystemSetting/e208809f0b4d973ffca59891628790de.vehicle',
    ),
    282 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'b145009aa902e70f44ab92c71bb02b6b',
      'native_key' => 'clear_cache_refresh_trees',
      'filename' => 'modSystemSetting/d9d19a374b14e03ee992a451fa935c2a.vehicle',
    ),
    283 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '34e327d5ab3aa709a36b35c88bc093da',
      'native_key' => 'compress_css',
      'filename' => 'modSystemSetting/95d38412f1045f2f648dad15a8c8edcd.vehicle',
    ),
    284 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'd6fdb126f4c1330d4fdf709f5837a84a',
      'native_key' => 'compress_js',
      'filename' => 'modSystemSetting/89dac79d75582769b585961925c57e7c.vehicle',
    ),
    285 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'ce2b74cf675044450e89741bb2bc682c',
      'native_key' => 'compress_js_max_files',
      'filename' => 'modSystemSetting/dcba58864bc1d675c150021e5d2071bc.vehicle',
    ),
    286 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '7007348fd9902631b5add8bb570f220d',
      'native_key' => 'compress_js_groups',
      'filename' => 'modSystemSetting/ebb75d0fb28b431647ef7a7c298f223b.vehicle',
    ),
    287 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '0b28a4a08cd6f284cd7a48fa569de79a',
      'native_key' => 'container_suffix',
      'filename' => 'modSystemSetting/58143b34ab49a07b312cb8c7645bf2d8.vehicle',
    ),
    288 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '34ef5666e5b97e308306bead926de5e9',
      'native_key' => 'context_tree_sort',
      'filename' => 'modSystemSetting/d67f3fe8fa3ba8752bc6a88b49c92929.vehicle',
    ),
    289 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'a111319341ecd1218618e3ce89d742c6',
      'native_key' => 'context_tree_sortby',
      'filename' => 'modSystemSetting/ad3492fe034358a94fd5ac32f0650246.vehicle',
    ),
    290 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'ed80bad919fac05688179d23f2fead8d',
      'native_key' => 'context_tree_sortdir',
      'filename' => 'modSystemSetting/df0730ec09ad7f17a4ee41c8d2aaaaf3.vehicle',
    ),
    291 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '81aa35ce1acf4b067355726ba25431a9',
      'native_key' => 'cultureKey',
      'filename' => 'modSystemSetting/ff1f5546fa776aee039abbf4be3c2491.vehicle',
    ),
    292 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '5c864130c5c0f25c33d9ec85a89dd443',
      'native_key' => 'date_timezone',
      'filename' => 'modSystemSetting/63fe5bdaba7315de1d6084fecd30ed54.vehicle',
    ),
    293 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '4a8026a3b1c0740a4bb61fd4172a0ece',
      'native_key' => 'debug',
      'filename' => 'modSystemSetting/314d1913123edd7eb8affb4a62721edd.vehicle',
    ),
    294 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '1fc0fdd1ea0bae95f67a3752ea88ad29',
      'native_key' => 'default_duplicate_publish_option',
      'filename' => 'modSystemSetting/1e6e7270b03dfef0dae12b7058ec2ed6.vehicle',
    ),
    295 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '9c1e12c8c6c63deae0da30d5bf561b7b',
      'native_key' => 'default_media_source',
      'filename' => 'modSystemSetting/d62cf39df0315a0cd6d4c2ae883478bb.vehicle',
    ),
    296 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '063ee191f2afdc550f55ccb54c805316',
      'native_key' => 'default_per_page',
      'filename' => 'modSystemSetting/dc11f668ac73fc2096c0a38adede2a71.vehicle',
    ),
    297 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'ad33a59b0b19ae705e51b179a8881eeb',
      'native_key' => 'default_context',
      'filename' => 'modSystemSetting/f44daa0983fe14ed4f5ff46cc01b7e5d.vehicle',
    ),
    298 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '3f9706c39817641ca1029106f10c1ab1',
      'native_key' => 'default_template',
      'filename' => 'modSystemSetting/f7fe6ecaf83716eb5e94f819954dadc1.vehicle',
    ),
    299 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'f905c88128c06fa8342a3801d0606f77',
      'native_key' => 'default_content_type',
      'filename' => 'modSystemSetting/36e1b6cb056cf8e717cd71d5ee4efeeb.vehicle',
    ),
    300 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'f83a525d5f79db3ddc48e1a5387370d2',
      'native_key' => 'editor_css_path',
      'filename' => 'modSystemSetting/b65746c2522409031af5345959331ccb.vehicle',
    ),
    301 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '484fe6b928117a08cf144236b04b2caa',
      'native_key' => 'editor_css_selectors',
      'filename' => 'modSystemSetting/a9e319540b9fb66f909d1ca1936a2f54.vehicle',
    ),
    302 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'c5539025bf55addf2d12847cc732fe67',
      'native_key' => 'emailsender',
      'filename' => 'modSystemSetting/71ed89878b089407312f1348cc9e448e.vehicle',
    ),
    303 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '679fd9dd1320464e54b4e1da46334e4d',
      'native_key' => 'emailsubject',
      'filename' => 'modSystemSetting/6abc84d93accb80f9fa7c697af4a068a.vehicle',
    ),
    304 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'c7821f8fc18ebea164efda7d0ed4262b',
      'native_key' => 'enable_dragdrop',
      'filename' => 'modSystemSetting/f8025e96110cc9a4068f44e54174fa0f.vehicle',
    ),
    305 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'f2f8436c1c896ac150dc87d4f279b69d',
      'native_key' => 'error_page',
      'filename' => 'modSystemSetting/0dc31a199b04914f815c7657d1d6a076.vehicle',
    ),
    306 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '8ade30b4176b3fc4fc0c84528f139227',
      'native_key' => 'failed_login_attempts',
      'filename' => 'modSystemSetting/b3101d47219452974c25ffcd191d760c.vehicle',
    ),
    307 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '58a90f42725a59a9d8c0d6f2074c8c70',
      'native_key' => 'fe_editor_lang',
      'filename' => 'modSystemSetting/7159c4d11cfc3d4de3af75a73a65184a.vehicle',
    ),
    308 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '5640b047d6ef0470bbbd3c949f93800a',
      'native_key' => 'feed_modx_news',
      'filename' => 'modSystemSetting/5587a68bd9f697d9509bc94e2904d393.vehicle',
    ),
    309 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '28a56564d0e6d61cb654160d8c363f5e',
      'native_key' => 'feed_modx_news_enabled',
      'filename' => 'modSystemSetting/e48c7fbddec8e8ce20aac7cb0fa7dbdb.vehicle',
    ),
    310 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '9eee850f5c7ca76a10a22f76e8ad272c',
      'native_key' => 'feed_modx_security',
      'filename' => 'modSystemSetting/20c5d3ad1675a1799d8d7e06f9b48532.vehicle',
    ),
    311 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '9fb67ecebf4dcf51fe4f5ebe73272d42',
      'native_key' => 'feed_modx_security_enabled',
      'filename' => 'modSystemSetting/f0c86f169bb28bd676ebc6171ee1fef5.vehicle',
    ),
    312 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'e47c24543bfe07e082a960120b04c9fa',
      'native_key' => 'filemanager_path',
      'filename' => 'modSystemSetting/ffd5f4634a78105442d9e8b0a7e68e03.vehicle',
    ),
    313 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '41062db58f92a7f54b6f909db852a57e',
      'native_key' => 'filemanager_path_relative',
      'filename' => 'modSystemSetting/7e76b0107de679953fe7ab014b1a5162.vehicle',
    ),
    314 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '0c57d5395483e115b321dabd26d79150',
      'native_key' => 'filemanager_url',
      'filename' => 'modSystemSetting/8df9569f8bbe795d6bc6bc1ea6f24583.vehicle',
    ),
    315 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '896ea52802bbe6b7f5114f5cdcdf1d2a',
      'native_key' => 'filemanager_url_relative',
      'filename' => 'modSystemSetting/2d89aa9556af51913e08cd0bc842b3ca.vehicle',
    ),
    316 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '3a958765ed7da2194a5706a84d8afa6c',
      'native_key' => 'forgot_login_email',
      'filename' => 'modSystemSetting/98760c38ba0416675472f15dc771dd14.vehicle',
    ),
    317 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '6b0eee18428b2e29e7383bbfe1be617f',
      'native_key' => 'form_customization_use_all_groups',
      'filename' => 'modSystemSetting/c5962efbf09675ddf90987af2675662e.vehicle',
    ),
    318 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '04f493932a78219da7d029af5e471381',
      'native_key' => 'forward_merge_excludes',
      'filename' => 'modSystemSetting/d5d4da191648e7acf0555a89a3b1c6a6.vehicle',
    ),
    319 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'c7e1702d6d352e5d18a16f539e52ac92',
      'native_key' => 'friendly_alias_lowercase_only',
      'filename' => 'modSystemSetting/f2e412260c40e0de8aa91fd433caf0e0.vehicle',
    ),
    320 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '64ed092f2126b47c80e3fbfbb0f9d112',
      'native_key' => 'friendly_alias_max_length',
      'filename' => 'modSystemSetting/b63534e7c6b306e9af36d1374018ca15.vehicle',
    ),
    321 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'fb920c26ba8a6615564b6e5e69c79c89',
      'native_key' => 'friendly_alias_restrict_chars',
      'filename' => 'modSystemSetting/940fe5e7747717df8e594f230935fa84.vehicle',
    ),
    322 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '35ce3586b426a8f5180f8cefd24cb7aa',
      'native_key' => 'friendly_alias_restrict_chars_pattern',
      'filename' => 'modSystemSetting/336935736bb98a562b621221ba68b061.vehicle',
    ),
    323 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '07a9e505a8202d64d33ff3af26e5b282',
      'native_key' => 'friendly_alias_strip_element_tags',
      'filename' => 'modSystemSetting/e1b6a691feee5e9b8b0e0913af7adf5b.vehicle',
    ),
    324 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '79ddd314bd8d492762cf658f23c81839',
      'native_key' => 'friendly_alias_translit',
      'filename' => 'modSystemSetting/fa25b83364c97b0a530bfd49a686b373.vehicle',
    ),
    325 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'dfdd4f091cf73f63b1fac09f3fa8047b',
      'native_key' => 'friendly_alias_translit_class',
      'filename' => 'modSystemSetting/3893fd8e914b62852302dfbb568ac26c.vehicle',
    ),
    326 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'ef2f029ac35d21926bc77a10c7b36dbd',
      'native_key' => 'friendly_alias_translit_class_path',
      'filename' => 'modSystemSetting/a4528d6058843ddea3d9000c8287f184.vehicle',
    ),
    327 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'a68f38343b2d2dd5db6bb457f67d91a1',
      'native_key' => 'friendly_alias_trim_chars',
      'filename' => 'modSystemSetting/46d237f424253083b637e98d7c347c6e.vehicle',
    ),
    328 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '73c364f4a2044c9b0379595a4395bb19',
      'native_key' => 'friendly_alias_word_delimiter',
      'filename' => 'modSystemSetting/2bb9969cbf1bd96d354ca632a4730f31.vehicle',
    ),
    329 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '6e93f4a4993ffd6b443b6463ebc7de49',
      'native_key' => 'friendly_alias_word_delimiters',
      'filename' => 'modSystemSetting/57e0aea4e9cb2853237f234c54637efb.vehicle',
    ),
    330 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'ba7e93a69e005842b871725506eb45a4',
      'native_key' => 'friendly_urls',
      'filename' => 'modSystemSetting/ff313f443b755f42d389d0f2983c7218.vehicle',
    ),
    331 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'e829041fb0f5a19e191dd7b03dae9c3b',
      'native_key' => 'friendly_urls_strict',
      'filename' => 'modSystemSetting/92bb498e3b6bc41d3b720b7982fb9119.vehicle',
    ),
    332 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '4b3c2e956a59b09abc51abdbbf852c90',
      'native_key' => 'global_duplicate_uri_check',
      'filename' => 'modSystemSetting/2997f667fb3b4831236de30baa73a102.vehicle',
    ),
    333 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '7d1ef63e4a525a86b1fdab4eb4fc448a',
      'native_key' => 'hidemenu_default',
      'filename' => 'modSystemSetting/8d06d7df1f727683095ee8b83a6523f1.vehicle',
    ),
    334 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'f3548d408a7a8dca9882fe82d00e7ab4',
      'native_key' => 'inline_help',
      'filename' => 'modSystemSetting/48974d512b2de4d310d7259324338975.vehicle',
    ),
    335 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '9d9a3c382e0493f9d962e705dcf37ece',
      'native_key' => 'locale',
      'filename' => 'modSystemSetting/c185b3c213b4315d1590c1fe3c8005e5.vehicle',
    ),
    336 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'c3bff3e1e3b91e9e0f4e1075ba286e45',
      'native_key' => 'log_level',
      'filename' => 'modSystemSetting/925fdcc171530daf5cb76736e1e34e21.vehicle',
    ),
    337 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '975cf0be1c9b6a35b848b91eb0b72d23',
      'native_key' => 'log_target',
      'filename' => 'modSystemSetting/94924567944d82475443f10862bb890d.vehicle',
    ),
    338 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '02aad2d9024798530b956e3c9f3175b8',
      'native_key' => 'link_tag_scheme',
      'filename' => 'modSystemSetting/f94b95c40ca27c9633db9636fbfbe29f.vehicle',
    ),
    339 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '60b785c123dd34b619edd9014c9b825d',
      'native_key' => 'lock_ttl',
      'filename' => 'modSystemSetting/9739dc9b978375bfe0b05eaba4d8d852.vehicle',
    ),
    340 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '205ff9235e64caf3df00b0727778570e',
      'native_key' => 'mail_charset',
      'filename' => 'modSystemSetting/fe6cba2ed96de13a20e0edf83f72b093.vehicle',
    ),
    341 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '553d52804fc457b07600120c3b1cb8ae',
      'native_key' => 'mail_encoding',
      'filename' => 'modSystemSetting/9441c4e88402e931340e356384d20701.vehicle',
    ),
    342 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '9b7a004baab06cba69fe8b13e05e985f',
      'native_key' => 'mail_use_smtp',
      'filename' => 'modSystemSetting/a1e2a5fb59253ab27e88d056b13ccb85.vehicle',
    ),
    343 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '016379aee59e6a34801c4c0a54910322',
      'native_key' => 'mail_smtp_auth',
      'filename' => 'modSystemSetting/e84ac91c058b7e79b98523809735c1ee.vehicle',
    ),
    344 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'ad3884c392068a43b9949532f2e20816',
      'native_key' => 'mail_smtp_helo',
      'filename' => 'modSystemSetting/83506a438f0ec411f001115d4ebd0aa6.vehicle',
    ),
    345 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'd1610f8be06d370afa67746dc5f0a521',
      'native_key' => 'mail_smtp_hosts',
      'filename' => 'modSystemSetting/80921acaa82c13936de335f1c7616b16.vehicle',
    ),
    346 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '858a6525c751187f5102c94b4c3b0098',
      'native_key' => 'mail_smtp_keepalive',
      'filename' => 'modSystemSetting/9b7dd877547255fbaea73000f240fe35.vehicle',
    ),
    347 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'b81e2fdf3fc3f82ff17df15abd1df8da',
      'native_key' => 'mail_smtp_pass',
      'filename' => 'modSystemSetting/2589bc57eb12f044b30440d306f7f4e5.vehicle',
    ),
    348 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'c1785eafc8c18b18206f5ff8e453788b',
      'native_key' => 'mail_smtp_port',
      'filename' => 'modSystemSetting/5ca14765d48b2a15e9f7d50d242c2638.vehicle',
    ),
    349 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '20e86e6f62a0760bfa0f768cc0cf5c6f',
      'native_key' => 'mail_smtp_prefix',
      'filename' => 'modSystemSetting/4631306f0cebbe8c65255e81b0beeb38.vehicle',
    ),
    350 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'bdd9ec6bc7524effb232be8a9e6c8c4b',
      'native_key' => 'mail_smtp_single_to',
      'filename' => 'modSystemSetting/1fe8629271ac7fb9a4c11ef5139c4e01.vehicle',
    ),
    351 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'c8e637eed05b314fa3064642748ee444',
      'native_key' => 'mail_smtp_timeout',
      'filename' => 'modSystemSetting/42b7caa13a80d716238017f31fb6c275.vehicle',
    ),
    352 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '96f2cb92824ce7f4e9d155494ee88315',
      'native_key' => 'mail_smtp_user',
      'filename' => 'modSystemSetting/bb9f1bd0ddcba5b4df7da0543c422151.vehicle',
    ),
    353 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'b3c1d3ee10f4b164aa7a990e571c5d89',
      'native_key' => 'manager_date_format',
      'filename' => 'modSystemSetting/253975b3cf02472a0db65a53cee98e92.vehicle',
    ),
    354 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '3f92d6af61544aa45d52fe25b58fb075',
      'native_key' => 'manager_favicon_url',
      'filename' => 'modSystemSetting/09f92f055d11e4e53c9963462e4bcf42.vehicle',
    ),
    355 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '12e4b08a54a5c5287f8f7149ad8c4e3c',
      'native_key' => 'manager_html5_cache',
      'filename' => 'modSystemSetting/81cbb42179eafc9d75741560ecf187a2.vehicle',
    ),
    356 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'fa1578a91318c3a56e80480892abd2be',
      'native_key' => 'manager_js_cache_file_locking',
      'filename' => 'modSystemSetting/26ee6f587048484befc9d2b6c3d44ce8.vehicle',
    ),
    357 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '6e2d0b645c43b7b495b0aa253d4ad84a',
      'native_key' => 'manager_js_cache_max_age',
      'filename' => 'modSystemSetting/758879743443a2a5548ee7b8b1d165ce.vehicle',
    ),
    358 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '7b1043dc4aafd9e0a3e5a7c4787300c9',
      'native_key' => 'manager_js_document_root',
      'filename' => 'modSystemSetting/426c555f8b98b244e61d56383ecedea5.vehicle',
    ),
    359 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '7a0c9c1b0446b1c832ad765cc85ff74c',
      'native_key' => 'manager_js_zlib_output_compression',
      'filename' => 'modSystemSetting/c1e4876ffacef27454d4ed594d6b582d.vehicle',
    ),
    360 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '79e7f0459c77323e9aac009677946b96',
      'native_key' => 'manager_time_format',
      'filename' => 'modSystemSetting/3ce28807e9022ec3d8dc3fd7eb528628.vehicle',
    ),
    361 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'de02af732575872ea6499f4412e84874',
      'native_key' => 'manager_direction',
      'filename' => 'modSystemSetting/f8d7578b676d209052cb617ae19092e9.vehicle',
    ),
    362 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'f455d7532423ab247bab4225c8561f67',
      'native_key' => 'manager_lang_attribute',
      'filename' => 'modSystemSetting/688f4e985397de1f9a84213f69e5a55f.vehicle',
    ),
    363 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'f4cd5d9852369cbd5a4d4870e8afef9a',
      'native_key' => 'manager_language',
      'filename' => 'modSystemSetting/e8ae963ec4816eee3cd1ab5187407b4d.vehicle',
    ),
    364 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'f2726974d1f525202de3bd4609024d49',
      'native_key' => 'manager_login_url_alternate',
      'filename' => 'modSystemSetting/e270cbae637ff5cc0f599f153de163b1.vehicle',
    ),
    365 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'ba71b23dda8a7430b906a60001df2f7d',
      'native_key' => 'manager_theme',
      'filename' => 'modSystemSetting/1757e54a488572cd40bf4a4130caf583.vehicle',
    ),
    366 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '3f8e3fa99ae28db500240b5eb07c1c43',
      'native_key' => 'manager_week_start',
      'filename' => 'modSystemSetting/3a2f36b83c7ca3b2fb663acd01409adf.vehicle',
    ),
    367 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'e6f0a3fa90b54d49482636eec962e5c2',
      'native_key' => 'modx_browser_default_sort',
      'filename' => 'modSystemSetting/0c0b67227a364b52dc67d7ec1be97764.vehicle',
    ),
    368 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '4bd5e6f09cf580bb088382f8da9e8dc3',
      'native_key' => 'modx_charset',
      'filename' => 'modSystemSetting/1df0361d4d72e37ee21c65c02b824327.vehicle',
    ),
    369 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'aca14d4706b76c9ba7231b41da266db4',
      'native_key' => 'principal_targets',
      'filename' => 'modSystemSetting/7e48618130b9e33d1c81c2cbb46f1ee2.vehicle',
    ),
    370 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '9bf7338f003b568103fa199b28d0a0d9',
      'native_key' => 'proxy_auth_type',
      'filename' => 'modSystemSetting/6130f2379f9ea0a5350bf9db546d5562.vehicle',
    ),
    371 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'd9fdaf8598f854404bb289ed7c026410',
      'native_key' => 'proxy_host',
      'filename' => 'modSystemSetting/64c892da8261130116a72ab9f42091ed.vehicle',
    ),
    372 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '8e6dc28502d433a558ab587a95d17ea4',
      'native_key' => 'proxy_password',
      'filename' => 'modSystemSetting/f3af37604d8918f189e81b9167888a94.vehicle',
    ),
    373 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '00ebbcc40d40481a36b3d4cc6bbe060a',
      'native_key' => 'proxy_port',
      'filename' => 'modSystemSetting/820cb6e58ee489b83897f0cb29d69f0f.vehicle',
    ),
    374 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '52afbdce1ab2c240d43a0f71fb0b8346',
      'native_key' => 'proxy_username',
      'filename' => 'modSystemSetting/f9e368aebd48a583d9904ba8be0d7b30.vehicle',
    ),
    375 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '5a0479b986e4c1c219c1fca163a59bba',
      'native_key' => 'password_generated_length',
      'filename' => 'modSystemSetting/0a52886da4a767e48d862ddad2784d5a.vehicle',
    ),
    376 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '97ade589be1317bea6e27f079dc256c2',
      'native_key' => 'password_min_length',
      'filename' => 'modSystemSetting/1d1ea25083a0450af13f96e5b24dd327.vehicle',
    ),
    377 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'b4fd38a2f702e4057d0fd794f27b7665',
      'native_key' => 'phpthumb_allow_src_above_docroot',
      'filename' => 'modSystemSetting/116cafeadc0e5f30ae830b7dc6fd6b35.vehicle',
    ),
    378 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '89237c9a8fd39ad46921c534d1e11201',
      'native_key' => 'phpthumb_cache_maxage',
      'filename' => 'modSystemSetting/51f8e6c3cd25e043dc1a3c1de0156f68.vehicle',
    ),
    379 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '268e1db6f9299da65037c06356298a26',
      'native_key' => 'phpthumb_cache_maxsize',
      'filename' => 'modSystemSetting/f2d17d0ef32f66cfcd06db9b8398dd1d.vehicle',
    ),
    380 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'fdafa5de7f727cd16e5d7043557551c3',
      'native_key' => 'phpthumb_cache_maxfiles',
      'filename' => 'modSystemSetting/45ee5cc6c8624510897d37bcbed4ac96.vehicle',
    ),
    381 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '518b683a81f7e727fc36c9912445d20f',
      'native_key' => 'phpthumb_cache_source_enabled',
      'filename' => 'modSystemSetting/198e2fcb2b5735e1cbdcf0dc7f800b38.vehicle',
    ),
    382 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'b1175b36c76c0c3939746de63710404c',
      'native_key' => 'phpthumb_document_root',
      'filename' => 'modSystemSetting/6c20ba0178744673dfca72d13e37828e.vehicle',
    ),
    383 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '145e67e953a2055acf7144cb62acddd3',
      'native_key' => 'phpthumb_error_bgcolor',
      'filename' => 'modSystemSetting/b06176a836b09a897e4e6e7bbc04e9ef.vehicle',
    ),
    384 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '1ab6f932538ddb5b47d69e7f091f82cc',
      'native_key' => 'phpthumb_error_textcolor',
      'filename' => 'modSystemSetting/afd45a97ce0cb2990660b30c6e542c59.vehicle',
    ),
    385 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'd1ecf3376d660c6dec37e29dac23123d',
      'native_key' => 'phpthumb_error_fontsize',
      'filename' => 'modSystemSetting/577e1dbc8c613688be36d2bdb79aa499.vehicle',
    ),
    386 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'c2e4b6d5ecafaadd9502a0288046e672',
      'native_key' => 'phpthumb_far',
      'filename' => 'modSystemSetting/caf7b8b8a83199b515d7ee766121e62e.vehicle',
    ),
    387 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '89353e66a778e4c1f4241bbff7cc8f4b',
      'native_key' => 'phpthumb_imagemagick_path',
      'filename' => 'modSystemSetting/bb6bf700d612800772702ae70045dfd9.vehicle',
    ),
    388 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'c52242c84d6ba0a22e02a9e394ecb4e7',
      'native_key' => 'phpthumb_nohotlink_enabled',
      'filename' => 'modSystemSetting/26fbe40505cf310c4ffcdcba1ad40445.vehicle',
    ),
    389 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '509678ebc92de2fd6cc5b50f393b3304',
      'native_key' => 'phpthumb_nohotlink_erase_image',
      'filename' => 'modSystemSetting/77096258c68771d55b06427e42c6a553.vehicle',
    ),
    390 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '69d48df53eaa252caaf407973716b23c',
      'native_key' => 'phpthumb_nohotlink_valid_domains',
      'filename' => 'modSystemSetting/9fad43734d9e9ec553d9c44458448dd3.vehicle',
    ),
    391 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '183f1761180a78c083c8291ed1cf6262',
      'native_key' => 'phpthumb_nohotlink_text_message',
      'filename' => 'modSystemSetting/fa1dbf7dd19da403bcdb5df31a3a02f1.vehicle',
    ),
    392 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'dc44bbfa5935080dc26ed33e0c7fd6ee',
      'native_key' => 'phpthumb_nooffsitelink_enabled',
      'filename' => 'modSystemSetting/2601d9b2ed22c47c63d53c998c0f10d4.vehicle',
    ),
    393 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '5f7274f5d07e3029bcfb534e518632ab',
      'native_key' => 'phpthumb_nooffsitelink_erase_image',
      'filename' => 'modSystemSetting/c19db26e47c34eb1c8ff1b2527ec8a77.vehicle',
    ),
    394 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'd986952630c21348d7a6d2574e786f9c',
      'native_key' => 'phpthumb_nooffsitelink_require_refer',
      'filename' => 'modSystemSetting/d1d1368753e3eb0225fa862a29215a71.vehicle',
    ),
    395 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'b304230ff84494c169eef81d47366c70',
      'native_key' => 'phpthumb_nooffsitelink_text_message',
      'filename' => 'modSystemSetting/722dc008344b6fc5d19c485058a97e2b.vehicle',
    ),
    396 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '7a95f075e56a014667214a7a23be50a6',
      'native_key' => 'phpthumb_nooffsitelink_valid_domains',
      'filename' => 'modSystemSetting/07e46b9d10aedbfefa4bb25f02ad5098.vehicle',
    ),
    397 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '0b6b485c077244d3e92869638b40cba2',
      'native_key' => 'phpthumb_nooffsitelink_watermark_src',
      'filename' => 'modSystemSetting/13378a8f29ffec002dd6c4e1a41295a2.vehicle',
    ),
    398 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '6b416d3ad2910e57cdf2227505ddeb3b',
      'native_key' => 'phpthumb_zoomcrop',
      'filename' => 'modSystemSetting/ccfbb571eacb7faebaaffe20e3e0b0c5.vehicle',
    ),
    399 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '2a924a33b16565071cefcb75e3bbae82',
      'native_key' => 'publish_default',
      'filename' => 'modSystemSetting/6f1d3992b957555cf2320a1dd8ded23d.vehicle',
    ),
    400 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'bb7ad6b21ed00020405b315042af26ad',
      'native_key' => 'rb_base_dir',
      'filename' => 'modSystemSetting/58d31ad2639d0a0745ea5ad06720817c.vehicle',
    ),
    401 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'bedb8ef6ceefafc54c6f6bb05d590a02',
      'native_key' => 'rb_base_url',
      'filename' => 'modSystemSetting/b4fe0d84e8e5c3ce44cf0156707b8828.vehicle',
    ),
    402 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'c42cae5e4ed0db0470e9b3e2486e063b',
      'native_key' => 'request_controller',
      'filename' => 'modSystemSetting/7a900c847f37984a450c30b0884a86ee.vehicle',
    ),
    403 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '91101222a4593d39a49ab8e1a8d28642',
      'native_key' => 'request_method_strict',
      'filename' => 'modSystemSetting/0c8fcdd80b2dc4ea1cfb9654d6255903.vehicle',
    ),
    404 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '26c9b9f5c5a92440692b80436131c216',
      'native_key' => 'request_param_alias',
      'filename' => 'modSystemSetting/6e7ea591d96ebefea5c7a50796576a1a.vehicle',
    ),
    405 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '8f42f71f240f8fc64391c101fe357e16',
      'native_key' => 'request_param_id',
      'filename' => 'modSystemSetting/5cc0f5819ed0d69b73a3e2944de4aeac.vehicle',
    ),
    406 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'da23080b937ff84e86cbe7e32233368c',
      'native_key' => 'resolve_hostnames',
      'filename' => 'modSystemSetting/41855024d478fe2cb1842b5dd046c331.vehicle',
    ),
    407 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '8d074a4e4434260aeb1208c5143a6baf',
      'native_key' => 'resource_tree_node_name',
      'filename' => 'modSystemSetting/69f1b198f527013b6e3bb92514b6d011.vehicle',
    ),
    408 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '499c97d3f8462ae6f5b1fd1f38612228',
      'native_key' => 'resource_tree_node_tooltip',
      'filename' => 'modSystemSetting/cb7d5b5a3f8ce02b13aa3e3f1be660d1.vehicle',
    ),
    409 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '31fd61a96495c502c1c05816bc8b7118',
      'native_key' => 'richtext_default',
      'filename' => 'modSystemSetting/299b5320d8da7ff54dfba42568ac0d23.vehicle',
    ),
    410 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '73b2768982bfe628c749b814eac14be9',
      'native_key' => 'search_default',
      'filename' => 'modSystemSetting/da494bddc91d655046b0c22a177c812a.vehicle',
    ),
    411 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '98d6007571617e493f83c8c939afb0ff',
      'native_key' => 'server_offset_time',
      'filename' => 'modSystemSetting/aec90f3381a1cc059285d88d088f68c1.vehicle',
    ),
    412 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'ed41bbbd32668e49b51cc857e622b017',
      'native_key' => 'server_protocol',
      'filename' => 'modSystemSetting/357a6c73e2a67f1d63c975e708b54805.vehicle',
    ),
    413 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'efc928e4f3353fdbb9da49277c9b4723',
      'native_key' => 'session_cookie_domain',
      'filename' => 'modSystemSetting/3b9113b9c1be9b5a3a17ca7dc3564704.vehicle',
    ),
    414 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'f4ffc346e99a12f54f87f351f7521496',
      'native_key' => 'session_cookie_lifetime',
      'filename' => 'modSystemSetting/06e245e8ace2a0033935d99c52ee2fec.vehicle',
    ),
    415 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '34704fb19b88f0a8dacb9ae34dfb5db8',
      'native_key' => 'session_cookie_path',
      'filename' => 'modSystemSetting/69878aca14bfc7bfc9dc7d88a8a1e7aa.vehicle',
    ),
    416 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '5eb066456d43c8f41cc94b27fc312203',
      'native_key' => 'session_cookie_secure',
      'filename' => 'modSystemSetting/79f6a4eefa7f6a78ba188ea3841accf1.vehicle',
    ),
    417 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'd210d9e2dc7e1cf7894bb54a9d347069',
      'native_key' => 'session_cookie_httponly',
      'filename' => 'modSystemSetting/6fa07dc14ec0d3c2286f7e9dad9547cc.vehicle',
    ),
    418 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'd8bb772beb535d2ecb2891396a816679',
      'native_key' => 'session_gc_maxlifetime',
      'filename' => 'modSystemSetting/43dcc99960826970aeaba765f5ec9a78.vehicle',
    ),
    419 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'b7ad7b6175255c7f5b09ec12133783cf',
      'native_key' => 'session_handler_class',
      'filename' => 'modSystemSetting/a8d54d34a87a11cf01a5367bafecc05a.vehicle',
    ),
    420 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '0218defae005162645e3886a174232b8',
      'native_key' => 'session_name',
      'filename' => 'modSystemSetting/317250275aa38747084a39db26ec9171.vehicle',
    ),
    421 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '889ce920ade59698ae2b4ae3e52f9005',
      'native_key' => 'set_header',
      'filename' => 'modSystemSetting/4b7127f9504ccde745615b5b40bd0877.vehicle',
    ),
    422 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '04071377c4105e7faed08b80b2fd2197',
      'native_key' => 'show_tv_categories_header',
      'filename' => 'modSystemSetting/efeff3dea91903d6c42b82ca73168898.vehicle',
    ),
    423 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '914257ec4b4f3ee351acb2bb05c35e25',
      'native_key' => 'signupemail_message',
      'filename' => 'modSystemSetting/e22914609f4663d4e787ac51da768431.vehicle',
    ),
    424 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '63d64b88379412ea64f1a0ca19bc3248',
      'native_key' => 'site_name',
      'filename' => 'modSystemSetting/7b9f6f123d2b6720a668e0355e3f9585.vehicle',
    ),
    425 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'e1d59276f6721daf716ac6b6a95ca16f',
      'native_key' => 'site_start',
      'filename' => 'modSystemSetting/72a2fabc0d74a21f532ab34892e63adb.vehicle',
    ),
    426 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '6859a38197617db8e4dd353a5f3537f2',
      'native_key' => 'site_status',
      'filename' => 'modSystemSetting/db7027e563521b6aefd21aacfbd9e0f6.vehicle',
    ),
    427 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '2fd6868ade7db922f80d48a3aeb53ae6',
      'native_key' => 'site_unavailable_message',
      'filename' => 'modSystemSetting/140f1d3bde803f634c859be412cb8fe1.vehicle',
    ),
    428 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '396f994fef7dac82f7e0941a0d3d680f',
      'native_key' => 'site_unavailable_page',
      'filename' => 'modSystemSetting/bad8ed5bd46e22fa71f0910b02fc8018.vehicle',
    ),
    429 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'c0d4806d6469bd95237ddb878bb26d9b',
      'native_key' => 'strip_image_paths',
      'filename' => 'modSystemSetting/d55693a7539ab7ea7e549da9210d71e9.vehicle',
    ),
    430 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'd243b348653324beb8aee8ddd9b696ad',
      'native_key' => 'symlink_merge_fields',
      'filename' => 'modSystemSetting/28fec367de5460d3f9efe7e961fce7a8.vehicle',
    ),
    431 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '3bbdedc3ab2c764b99c3f2f6a93a3924',
      'native_key' => 'topmenu_show_descriptions',
      'filename' => 'modSystemSetting/037e386a3703bfce87fab0840d6dc1de.vehicle',
    ),
    432 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '7157a9325c53c1130068c9687981eed3',
      'native_key' => 'tree_default_sort',
      'filename' => 'modSystemSetting/1cea0ae6a28c93f8cce7d3173de5fa13.vehicle',
    ),
    433 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '637475104d832aed7da27eea50b70bd3',
      'native_key' => 'tree_root_id',
      'filename' => 'modSystemSetting/0e3236e62805c52e71eabf1a49e2fa66.vehicle',
    ),
    434 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'a77ff430ee796429f6dde3cc1c3ca898',
      'native_key' => 'tvs_below_content',
      'filename' => 'modSystemSetting/128cd47aa2dcf34ba1e8ef277f63bafc.vehicle',
    ),
    435 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'ae9419d77d75cde3c48e42c8db35004f',
      'native_key' => 'udperms_allowroot',
      'filename' => 'modSystemSetting/730a01089952273b24291a63ab36da32.vehicle',
    ),
    436 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'f86d9ed6bb097db52c5e92ede32774b8',
      'native_key' => 'unauthorized_page',
      'filename' => 'modSystemSetting/c09220b74eb32226bd72940c67b34dc6.vehicle',
    ),
    437 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'b1edf9476a67d55b16eb4addcb3f2836',
      'native_key' => 'upload_files',
      'filename' => 'modSystemSetting/0209bbc24f2e0d4003ef6aaa9920a41c.vehicle',
    ),
    438 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '772ac7eea362d4b96f36ab62a5643b00',
      'native_key' => 'upload_flash',
      'filename' => 'modSystemSetting/72a4adce68dc8cad2a681a33cb46237c.vehicle',
    ),
    439 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '8024e1ac42c4477f412dc19fb728dff1',
      'native_key' => 'upload_images',
      'filename' => 'modSystemSetting/ec431cd3ff4611cae5de50cf2e7120f5.vehicle',
    ),
    440 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '61ba87e9cd186ca34a4d6a2881f46d02',
      'native_key' => 'upload_maxsize',
      'filename' => 'modSystemSetting/2682428a3b399680cef0d7321edad4ee.vehicle',
    ),
    441 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'daf99a53f6f6c53298069d43e2bc4954',
      'native_key' => 'upload_media',
      'filename' => 'modSystemSetting/70b4dabc234c04029dd30798aca5c80d.vehicle',
    ),
    442 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '69f4d5d88c6d2c3850ede222d81e8e95',
      'native_key' => 'use_alias_path',
      'filename' => 'modSystemSetting/03c026c1d3ddc38667844ac47b721dc6.vehicle',
    ),
    443 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '52f61a7ae602227154925035c8a9e0ee',
      'native_key' => 'use_browser',
      'filename' => 'modSystemSetting/2bdfc1989370231b48e00651e2dffa40.vehicle',
    ),
    444 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '970e30a2e6dfd51ce51fc821898c4e42',
      'native_key' => 'use_editor',
      'filename' => 'modSystemSetting/43c6538f8ae1db129b0d1cef5144afab.vehicle',
    ),
    445 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'a23d4c4f5b4830513461c139bd819496',
      'native_key' => 'use_multibyte',
      'filename' => 'modSystemSetting/88539f488ec5a72fe5876ef33facaeb1.vehicle',
    ),
    446 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'b8338468c8ca2fd82800a45d4fd4cb19',
      'native_key' => 'use_weblink_target',
      'filename' => 'modSystemSetting/9f31ac5cc02e27503bb624e3b59b03fa.vehicle',
    ),
    447 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'ca964e4719e9c77cf76cd3f804ddc550',
      'native_key' => 'webpwdreminder_message',
      'filename' => 'modSystemSetting/e3572e8c3f5acb2d4024b86e682a59bb.vehicle',
    ),
    448 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '939d0509de9163a0c6d6787c094adb2f',
      'native_key' => 'websignupemail_message',
      'filename' => 'modSystemSetting/53131087f464a9be866accec01fe3417.vehicle',
    ),
    449 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '5a4d23a076a61231f3c21bc0395097b5',
      'native_key' => 'welcome_screen',
      'filename' => 'modSystemSetting/024556be42e52b3274aad43ea1488270.vehicle',
    ),
    450 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '7384b895aae16aa8073b8e3eece5df7d',
      'native_key' => 'welcome_screen_url',
      'filename' => 'modSystemSetting/670283a97cd2911c7a6b093226ce351b.vehicle',
    ),
    451 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '0485aa0a90505f5dfcedb254a208fb02',
      'native_key' => 'which_editor',
      'filename' => 'modSystemSetting/d3e6cc4df21dfcf70897ea14e04dc32f.vehicle',
    ),
    452 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'b869cf8b2c3880414739530615dea7a4',
      'native_key' => 'which_element_editor',
      'filename' => 'modSystemSetting/8ddf8c78e95c78abcf7930367d183177.vehicle',
    ),
    453 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '37b75f76be4a9bf534e9421c46a68119',
      'native_key' => 'xhtml_urls',
      'filename' => 'modSystemSetting/da3cf664e42bfadccfc30d9a714994d0.vehicle',
    ),
    454 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modContextSetting',
      'guid' => '3705c6d4a181d3600c28f0cad838cdb9',
      'native_key' => 
      array (
        0 => 'mgr',
        1 => 'allow_tags_in_post',
      ),
      'filename' => 'modContextSetting/b52d4c1442ac1885039dd59b25c35e49.vehicle',
    ),
    455 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modContextSetting',
      'guid' => '047d48da89e4ef8eec0c616920b15229',
      'native_key' => 
      array (
        0 => 'mgr',
        1 => 'modRequest.class',
      ),
      'filename' => 'modContextSetting/db4d7530cd4261b60345130efed05c74.vehicle',
    ),
    456 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modUserGroup',
      'guid' => 'c7a75c38c4a0926cb7bf97caf969839c',
      'native_key' => 1,
      'filename' => 'modUserGroup/97e500ba3c6216196cd13444e8d174ca.vehicle',
    ),
    457 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modDashboard',
      'guid' => 'e5dfa0b6b9761cfa2f26be34af30ae8b',
      'native_key' => 1,
      'filename' => 'modDashboard/1aaee9be513e139065df525eb2202017.vehicle',
    ),
    458 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modMediaSource',
      'guid' => '27e3d5c1d62aeefd69ba00c9ce9a4af2',
      'native_key' => 1,
      'filename' => 'modMediaSource/940bdbfdc3dfb728cb82b72624ca6615.vehicle',
    ),
    459 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modDashboardWidget',
      'guid' => 'd907491f0d60f325411efbc35da03878',
      'native_key' => NULL,
      'filename' => 'modDashboardWidget/5ce46824c98e66cc283ace6c8c68293c.vehicle',
    ),
    460 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modDashboardWidget',
      'guid' => '30b3b960a408c3da16d4b44c2453c82f',
      'native_key' => NULL,
      'filename' => 'modDashboardWidget/43a99f1e4069692309c65a618a72ad0f.vehicle',
    ),
    461 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modDashboardWidget',
      'guid' => 'c9423e63af8984206a5dba314198345f',
      'native_key' => NULL,
      'filename' => 'modDashboardWidget/2d1dbf67a40a2d9bf1d0a8e3cfefa09c.vehicle',
    ),
    462 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modDashboardWidget',
      'guid' => 'fbd7c6d1fbf73c3359ae291f3e9968e3',
      'native_key' => NULL,
      'filename' => 'modDashboardWidget/314f59c750c78f60057b470cb0c5f109.vehicle',
    ),
    463 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modDashboardWidget',
      'guid' => '3d2be61f1507f06ef32d83cddf3992e9',
      'native_key' => NULL,
      'filename' => 'modDashboardWidget/90c47b47220367cdead6633ae11ebf99.vehicle',
    ),
    464 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modUserGroupRole',
      'guid' => 'f331dafbd5e960a2181219ba8d890ba0',
      'native_key' => 1,
      'filename' => 'modUserGroupRole/204c9845706ad1fb61fbb466f95bfdcb.vehicle',
    ),
    465 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modUserGroupRole',
      'guid' => 'eb34490de489854a3830c3fdc9cc521b',
      'native_key' => 2,
      'filename' => 'modUserGroupRole/a11cecbca294db84c5f240c61804006f.vehicle',
    ),
    466 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicyTemplateGroup',
      'guid' => 'a34d20c1b4c1b8f938bbd1364ba056c3',
      'native_key' => NULL,
      'filename' => 'modAccessPolicyTemplateGroup/d3d27dc1f8d7fc908e4f3f7e5fab1136.vehicle',
    ),
    467 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicyTemplateGroup',
      'guid' => '6305d1ad1da8c890966851687ee1d6bc',
      'native_key' => NULL,
      'filename' => 'modAccessPolicyTemplateGroup/e26696ddafff94f902e60d4683277370.vehicle',
    ),
    468 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicyTemplateGroup',
      'guid' => '68b191baed4c8ebad699274b87c6eb4d',
      'native_key' => NULL,
      'filename' => 'modAccessPolicyTemplateGroup/ebe04505aeaae07a5fcfb2504c86f503.vehicle',
    ),
    469 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicyTemplateGroup',
      'guid' => 'c2271ac2e498c11870dbe699d5dee1df',
      'native_key' => NULL,
      'filename' => 'modAccessPolicyTemplateGroup/e65c99b86debd4bfde713d5f8104c18c.vehicle',
    ),
    470 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicyTemplateGroup',
      'guid' => 'f1dbc9edab526ef1f54a040970b95962',
      'native_key' => NULL,
      'filename' => 'modAccessPolicyTemplateGroup/1428c3ba248fd6eeff3473d5c03f0977.vehicle',
    ),
    471 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicyTemplate',
      'guid' => 'bed5628d5f3048e581bc88a6d4841051',
      'native_key' => NULL,
      'filename' => 'modAccessPolicyTemplate/064e53eeac615fbefce0ad51efdcd820.vehicle',
    ),
    472 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicyTemplate',
      'guid' => '49079c56ad9d6fe64b3c46380b93d002',
      'native_key' => NULL,
      'filename' => 'modAccessPolicyTemplate/3008562a1c911a0db27850a6b75e1b17.vehicle',
    ),
    473 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicyTemplate',
      'guid' => '8add7eca11a8e3d9dcf15f2bc6353d0f',
      'native_key' => NULL,
      'filename' => 'modAccessPolicyTemplate/7ff5df459bfa92c6777355c4142ac4d4.vehicle',
    ),
    474 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicyTemplate',
      'guid' => 'aa40c409c893b39bbd96745e52573719',
      'native_key' => NULL,
      'filename' => 'modAccessPolicyTemplate/b8f92f149520ccc5e6e841a3e0662be4.vehicle',
    ),
    475 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicyTemplate',
      'guid' => '02abcc7dff9eb97e2e5e9390b9cef473',
      'native_key' => NULL,
      'filename' => 'modAccessPolicyTemplate/ff163a2a1c6235a7294fede1f5c49785.vehicle',
    ),
    476 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicyTemplate',
      'guid' => '66ceed0ec38658800a1e19c6d4d682b7',
      'native_key' => NULL,
      'filename' => 'modAccessPolicyTemplate/2200bdf0af727846a51a743cdc95eada.vehicle',
    ),
    477 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicy',
      'guid' => 'cf415fb5f888e091cf4111cc73bdc17e',
      'native_key' => 1,
      'filename' => 'modAccessPolicy/ea93922e90a3dac76229465d29448c82.vehicle',
    ),
    478 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicy',
      'guid' => '852e6d5dbff6cd41e9ed4726573ab097',
      'native_key' => 2,
      'filename' => 'modAccessPolicy/0d1b875a3b91bed18ec6647fae0f1e95.vehicle',
    ),
    479 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicy',
      'guid' => 'b93f2ea44d7a7bd3bffad2670cd158de',
      'native_key' => 3,
      'filename' => 'modAccessPolicy/947ca85bb1a0348dee169fb60b10d580.vehicle',
    ),
    480 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicy',
      'guid' => 'ddeac7c1b470b2d875ac6e482aa7824c',
      'native_key' => 4,
      'filename' => 'modAccessPolicy/044376bf3a0dbfe2584975ae755116a6.vehicle',
    ),
    481 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicy',
      'guid' => '39da30bf66f9647bf39dc903400945ad',
      'native_key' => 5,
      'filename' => 'modAccessPolicy/e0606929e3dc13ef55767a5c793f9947.vehicle',
    ),
    482 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicy',
      'guid' => '2e686da1ef2da587c78f91c9c4ea5a59',
      'native_key' => 6,
      'filename' => 'modAccessPolicy/06899de98f160a94fb824f221db9117b.vehicle',
    ),
    483 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicy',
      'guid' => 'f375d943abc3a719847c02793ae4c4d9',
      'native_key' => 7,
      'filename' => 'modAccessPolicy/4e51af2b482a5fa68c8c13732467e3e3.vehicle',
    ),
    484 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicy',
      'guid' => '951679a76dd7bc8ae479a23cb207caf2',
      'native_key' => 8,
      'filename' => 'modAccessPolicy/2397712731142bd6f8fc1aeb924ac880.vehicle',
    ),
    485 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicy',
      'guid' => 'db7bd75d0c01e4dffc513d094567cf0b',
      'native_key' => 9,
      'filename' => 'modAccessPolicy/4dc1d3be2d01d2437548651d41b147b5.vehicle',
    ),
    486 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicy',
      'guid' => '4feb5fb28a86e67c4aacb4827b2af951',
      'native_key' => 10,
      'filename' => 'modAccessPolicy/dc450a7affa4adae9427be2fe3e5a3bb.vehicle',
    ),
    487 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicy',
      'guid' => '7bcb0fdcc1d5be9609655379fe8ce0c5',
      'native_key' => 11,
      'filename' => 'modAccessPolicy/14d264f40c321f2cb824789b10a0435e.vehicle',
    ),
    488 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modContext',
      'guid' => '4f3f2a2a0887df48531ecea6ba67a527',
      'native_key' => 'web',
      'filename' => 'modContext/30d8087d41cec4d968824496e1163b26.vehicle',
    ),
    489 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modContext',
      'guid' => '536200cbfd8f61f800dfb7079860308c',
      'native_key' => 'mgr',
      'filename' => 'modContext/c14eb1256ab6c95f844ced3addae4840.vehicle',
    ),
    490 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOFileVehicle',
      'class' => 'xPDOFileVehicle',
      'guid' => '18c38dbdad5052b723a0971a54700154',
      'native_key' => '18c38dbdad5052b723a0971a54700154',
      'filename' => 'xPDOFileVehicle/b0b51b3583ca173467fabdbeaa1decd7.vehicle',
    ),
    491 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOFileVehicle',
      'class' => 'xPDOFileVehicle',
      'guid' => 'b590ece30191b620df44609fa7933f09',
      'native_key' => 'b590ece30191b620df44609fa7933f09',
      'filename' => 'xPDOFileVehicle/11eb7f1b1806b425deec2b5a6020765c.vehicle',
    ),
    492 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOFileVehicle',
      'class' => 'xPDOFileVehicle',
      'guid' => 'f2106c4950b2a5d7cb84143a2cc73804',
      'native_key' => 'f2106c4950b2a5d7cb84143a2cc73804',
      'filename' => 'xPDOFileVehicle/66428576487f8655f07fdfcdc200ca13.vehicle',
    ),
    493 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOFileVehicle',
      'class' => 'xPDOFileVehicle',
      'guid' => '375b25ca41bf9a84b9e4c7f42709dd9b',
      'native_key' => '375b25ca41bf9a84b9e4c7f42709dd9b',
      'filename' => 'xPDOFileVehicle/28dae9a6e8aec06333819bb98e752fbf.vehicle',
    ),
    494 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOFileVehicle',
      'class' => 'xPDOFileVehicle',
      'guid' => '05f40bb051f5bc229b38e741b39a0051',
      'native_key' => '05f40bb051f5bc229b38e741b39a0051',
      'filename' => 'xPDOFileVehicle/de88dcb037d57b0a7fa195dc36539502.vehicle',
    ),
    495 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOFileVehicle',
      'class' => 'xPDOFileVehicle',
      'guid' => 'a809aed1b48e9d3f3afa29ba332ded68',
      'native_key' => 'a809aed1b48e9d3f3afa29ba332ded68',
      'filename' => 'xPDOFileVehicle/f0f2e1b9a45a10da2bf7a7269401962b.vehicle',
    ),
    496 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOFileVehicle',
      'class' => 'xPDOFileVehicle',
      'guid' => 'cf5c22c060a6cca410b2f0f2982d60d7',
      'native_key' => 'cf5c22c060a6cca410b2f0f2982d60d7',
      'filename' => 'xPDOFileVehicle/72e6f8436958588d58829e48881e7e1c.vehicle',
    ),
    497 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOFileVehicle',
      'class' => 'xPDOFileVehicle',
      'guid' => '4af95414b7e8b017ed019a1013ba1b47',
      'native_key' => '4af95414b7e8b017ed019a1013ba1b47',
      'filename' => 'xPDOFileVehicle/710b8328e84fab41c05dea7e4b9b7a6d.vehicle',
    ),
    498 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOFileVehicle',
      'class' => 'xPDOFileVehicle',
      'guid' => 'e18736ab550600326a725dbd7dc27cec',
      'native_key' => 'e18736ab550600326a725dbd7dc27cec',
      'filename' => 'xPDOFileVehicle/c6718c080f0c04a23fac3ad374562e11.vehicle',
    ),
    499 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOFileVehicle',
      'class' => 'xPDOFileVehicle',
      'guid' => 'abc67339b421f6e2124be555696febb9',
      'native_key' => 'abc67339b421f6e2124be555696febb9',
      'filename' => 'xPDOFileVehicle/94937aaf214017bdf5ef179afe743849.vehicle',
    ),
    500 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOFileVehicle',
      'class' => 'xPDOFileVehicle',
      'guid' => 'f410909cbc0a675351fd99e25637dae1',
      'native_key' => 'f410909cbc0a675351fd99e25637dae1',
      'filename' => 'xPDOFileVehicle/71f0917701a6ed771630b71a48060383.vehicle',
    ),
  ),
);