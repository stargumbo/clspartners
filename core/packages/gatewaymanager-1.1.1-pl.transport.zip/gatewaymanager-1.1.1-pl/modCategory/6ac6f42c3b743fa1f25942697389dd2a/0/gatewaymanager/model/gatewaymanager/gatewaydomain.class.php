<?php
class gatewayDomain extends xPDOSimpleObject {}