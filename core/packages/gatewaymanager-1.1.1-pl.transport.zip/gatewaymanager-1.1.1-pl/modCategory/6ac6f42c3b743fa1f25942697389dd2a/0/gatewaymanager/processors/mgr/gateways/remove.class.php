<?php

class GatewaysRemoveProcessor extends modObjectRemoveProcessor {
	public $classKey = 'gatewayDomain';
	public $languageTopics = array('gatewaymanager:default');
	public $objectType = 'gatewaymanager.gatewaydomain';
}
return 'GatewaysRemoveProcessor';

?>