<?php
require_once (dirname(dirname(__FILE__)) . '/gatewaydomain.class.php');
class gatewayDomain_mysql extends gatewayDomain {}