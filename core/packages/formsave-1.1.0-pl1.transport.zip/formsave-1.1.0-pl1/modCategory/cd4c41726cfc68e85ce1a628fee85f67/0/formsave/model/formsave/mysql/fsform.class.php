<?php
require_once (dirname(dirname(__FILE__)) . '/fsform.class.php');
class fsForm_mysql extends fsForm {}