FormSave is developed and maintained by SCHERP Ontwikkeling (http://www.scherpontwikkeling.nl)

Install the package through the MODX Repo and check the RTFM for usage.