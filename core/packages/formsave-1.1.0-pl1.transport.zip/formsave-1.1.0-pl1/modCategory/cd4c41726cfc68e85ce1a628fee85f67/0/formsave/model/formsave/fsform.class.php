<?php
class fsForm extends xPDOSimpleObject {}